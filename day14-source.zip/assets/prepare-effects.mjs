import {readFile,writeFile,mkdir,cp} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
const c=value=>({mode:'constant',value,min:value,max:value,curve:[{x:0,y:value},{x:1,y:value}],curveB:[{x:0,y:value},{x:1,y:value}]});
await mkdir('vfx-project/effects',{recursive:true});
const project=JSON.parse(await readFile('starter-project.json'));project.id='day14-recipes';project.name='Portal, exhaust, mist and heal';project.settings.lastEffectFile='heal.json';await writeFile('vfx-project/vfx-editor.prj',JSON.stringify(project,null,2));
for(const s of [
{id:'portal',profile:'three-world-3d',max:96,life:1.5,size:.10,rate:48,shape:'circle',radius:1,box:[0,0,0],rotation:[90,0,0],vmin:[0,0,0],vmax:[0,0,0],color:[.65,.8,1,1]},
{id:'exhaust',profile:'three-world-3d',max:80,life:.65,size:.10,rate:80,shape:'box',box:[.1,.1,.01],vmin:[-.08,-.08,-2],vmax:[.08,.08,-1.6],color:[.3,.75,1,.8]},
{id:'mist',profile:'three-world-3d',max:64,life:2,size:.22,rate:24,shape:'box',box:[1.2,.05,.25],vmin:[-.15,.15,-.08],vmax:[.15,.35,.08],color:[.7,.85,1,.28]},
{id:'heal',profile:'portable',max:32,life:.8,size:.12,count:32,shape:'circle',radius:.75,box:[0,0,0],rotation:[90,0,0],vmin:[0,0,0],vmax:[0,0,0],color:[.2,1,.55,.9]}
]){const fx=JSON.parse(await readFile('starter-effect.json'));Object.assign(fx,{id:s.id,name:s.id,targetProfile:s.profile});fx.timeline.duration=s.rate?10:1.2;const e=fx.emitters[0];Object.assign(e,{id:s.id+'-emitter',name:s.id,maxParticles:s.max,duration:s.rate?10:.05,loop:!!s.rate});
Object.assign(e.spawn,{shape:s.shape,box:s.box,radius:s.radius||0,radiusValue:c(s.radius||0),radiusThickness:0,rotation:s.rotation||[0,0,0],simulationSpace:s.id==='exhaust'?'world':'local',rate:s.rate||0,rateValue:c(s.rate||0),bursts:s.rate?[]:[{time:0,count:s.count,cycles:1,interval:0,probability:1}]});
e.initializeParticle.lifetime=c(s.life);e.initializeParticle.size=c(s.size);Object.assign(e.initializeParticle.velocity,{mode:'vector',min:s.vmin,max:s.vmax,speed:c(0)});e.initializeParticle.color.color=s.color;e.initializeParticle.color.colorB=s.color;
Object.assign(e.billboard,{sizeStart:s.size,sizeEnd:s.size,sizeValue:c(s.size)});e.color.start=s.color;e.color.end=[...s.color.slice(0,3),0];e.color.gradient.colorStops=[{position:0,color:s.color.slice(0,3)},{position:1,color:s.color.slice(0,3)}];e.color.gradient.alphaStops=[{position:0,alpha:0},{position:.12,alpha:s.color[3]},{position:1,alpha:0}];Object.assign(e.render,{depthTest:s.profile!=='portable',depthWrite:false,depthInk:false,blend:'alpha'});
if(s.id==='portal'){e.modules.velocityOverLifetime=true;e.advanced.velocityOverLifetime.space='world';e.advanced.velocityOverLifetime.orbital.z=c(2.4);e.advanced.velocityOverLifetime.radial=c(-.2);}
await writeFile('vfx-project/effects/'+s.id+'.json',JSON.stringify(fx,null,2));}
for(const action of ['validate','export']){const r=spawnSync(process.execPath,['node_modules/nixie-fx/dist/cli.js',action,'./vfx-project'],{encoding:'utf8'});console.log(r.stdout,r.stderr);if(r.status)process.exit(r.status);}
await cp('vfx-project/out/vfx','public/vfx',{recursive:true});
