# Day 8 particle examples

Four working source recipes accompany the Day 8 drafts. These are synthetic scenes and a synthetic button; no production game or performance result is represented.

## Run

```sh
npm install
npm run prepare-effects
npm run dev -- --port 5188
```

Open the server with one mode: `?mode=hover`, `?mode=snow`, `?mode=motes`, or `?mode=impact`. The existing local workspace reuses installed dependencies through a symlink. The source ZIP excludes that link; a recipient runs `npm install` to install the pinned dependencies.

`prepare-effects.mjs` derives new authoring definitions from the included starter effect and project files. The source is self-contained after dependency installation; the four authored definitions and validated export are also included. To validate or re-export the authored project directly:

```sh
npx nixie-fx validate ./vfx-project
npx nixie-fx export ./vfx-project
```

After a direct re-export, copy `vfx-project/out/vfx/` into `public/vfx/` before building. `npm run prepare-effects` performs that copy itself. The runtime uses the compiled bundle, not the authoring JSON. `npm run build` produces the deployable `dist/` folder.

## Contracts

- Hover: native button, separate hover/focus inputs, `setPosition()` on PixiJS 0.1.17, immediate stop/removal when inactive, reduced-motion support, and actual click counter.
- Snow: 20 particles/second, four-second lifetime, capacity 96, downward vector velocity, world volume above the floor. No collision or accumulation.
- Motes: six particles/second, four-second lifetime, capacity 32. Depth testing against opaque corridor geometry; no depth writing. No volumetric fog or overdraw benchmark.
- Impact: one 18-particle burst, 0.55-second lifetime, capacity 24, local positive-Z emission oriented to a supplied world normal. The visual demo uses a positive-Z wall. Other surface normals require target-scene checks.

Three.js modes have a depth diagnostic toggle and complete scene disposal. All rendering examples update once per frame in seconds and cap individual steps at 0.05 seconds.

## Checks

`verify-browser.mjs` uses the bundled Playwright package and installed Chrome on this machine. It captures real screenshots at desktop and mobile widths, examines canvas pixels, checks focus/activation/reduced motion, movement, lifetime completion, and teardown. Its runtime path is local verification infrastructure; adapt that import if reproducing elsewhere.

The export reports are recorded under `../evidence/export-check.json`. Three.js GPU depth semantics do not transfer to PixiJS, even though these simple definitions have supported simulation/export reports on both backends. Human target-device performance and target-game acceptance remain separate checks.
