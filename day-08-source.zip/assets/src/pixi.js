import {Application,Container} from 'pixi.js';
import {PixiVfxRenderer,createPixiVfx2dProjection} from 'nixie-fx/pixi';
import {loadEffect} from './bundle.js';
export async function runPixi(){
  const {effect}=await loadEffect('hover-ember','pixi2d');
  const stage=document.querySelector('#stage'),button=document.querySelector('#game-button');
  const app=new Application();await app.init({resizeTo:stage,background:0x172522,antialias:true});stage.prepend(app.canvas);
  const layer=new Container();app.stage.addChild(layer);
  const vfx=new PixiVfxRenderer({parent:layer,projection:createPixiVfx2dProjection({pixelsPerUnit:1,yAxis:'down'})});
  let instance=null,hovered=false,focused=false,disposed=false,activationCount=0;
  const motion=matchMedia('(prefers-reduced-motion: reduce)');
  function sync(){
    if(disposed)return;
    const shouldEmit=(hovered||focused)&&!motion.matches;
    if(shouldEmit){if(!instance||!instance.isActive){if(instance)vfx.removeEffect(instance,true);instance=vfx.createEffect(effect,{seed:42});}}
    else if(instance){instance.stop();vfx.removeEffect(instance,true);instance=null;}
  }
  const handlers={pointerenter:()=>{hovered=true;sync();},pointerleave:()=>{hovered=false;sync();},focus:()=>{focused=true;sync();},blur:()=>{focused=false;sync();},click:()=>{activationCount++;}};
  for(const [event,fn]of Object.entries(handlers))button.addEventListener(event,fn);
  motion.addEventListener('change',sync);button.style.display='block';
  document.querySelector('#action').hidden=true;document.querySelector('#depth').parentElement.hidden=true;
  function tick(t){
    if(disposed||document.hidden)return;
    if(instance){const b=button.getBoundingClientRect(),s=stage.getBoundingClientRect();instance.setPosition([b.left-s.left+b.width/2,b.top-s.top+b.height/2,0]);}
    vfx.update(Math.min(t.deltaMS/1000,0.05));
    if(instance&&!instance.isActive){vfx.removeEffect(instance,true);instance=null;}
    window.recipeState={mode:'hover',hovered,focused,reducedMotion:motion.matches,activationCount,disposed,stats:{...vfx.stats}};
    document.querySelector('#stats').textContent=JSON.stringify(window.recipeState,null,2);
  }
  app.ticker.add(tick);
  function dispose(){if(disposed)return;disposed=true;app.ticker.remove(tick);for(const [event,fn]of Object.entries(handlers))button.removeEventListener(event,fn);motion.removeEventListener('change',sync);vfx.destroy();app.destroy(true,{children:true});button.disabled=true;window.recipeState={mode:'hover',disposed:true};document.querySelector('#status').textContent='Disposed';document.querySelector('#dispose').disabled=true;}
  document.querySelector('#dispose').onclick=dispose;window.addEventListener('pagehide',dispose,{once:true});
  document.querySelector('#status').textContent='Ready';
}
