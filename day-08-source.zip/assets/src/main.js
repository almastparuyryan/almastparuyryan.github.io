import './style.css';
import {runPixi} from './pixi.js';
import {runThree} from './three.js';
const mode=new URLSearchParams(location.search).get('mode')||'hover';
const labels={hover:'Hover ember with keyboard focus',snow:'Snowfall over an opaque courtyard',motes:'Depth-tested corridor motes',impact:'Wall impact along a surface normal'};
document.querySelector('#title').textContent=labels[mode]||labels.hover;
Promise.resolve(mode==='hover'||!labels[mode]?runPixi():runThree(mode)).catch(error=>{document.querySelector('#status').textContent=error.message;console.error(error);});
