import * as THREE from 'three';
import {ThreeVfxRenderer} from 'nixie-fx/three';
import {loadEffect} from './bundle.js';
export async function runThree(mode){
  const id={snow:'snowfall',motes:'corridor-motes',impact:'wall-sparks'}[mode];
  const {effect:original}=await loadEffect(id,'three3d');
  const host=document.querySelector('#stage'),scene=new THREE.Scene();scene.background=new THREE.Color(0x162722);
  const camera=new THREE.PerspectiveCamera(50,1,0.1,60);camera.position.set(mode==='motes'?0:4,2.5,mode==='motes'?6:7);camera.lookAt(0,1,0);
  const renderer=new THREE.WebGLRenderer({antialias:true,preserveDrawingBuffer:true});renderer.setPixelRatio(Math.min(devicePixelRatio,2));host.append(renderer.domElement);
  const material=new THREE.MeshBasicMaterial({color:0x456b5b});
  const floor=new THREE.Mesh(new THREE.BoxGeometry(9,0.12,12),material);floor.position.y=-0.06;scene.add(floor);
  const wall=new THREE.Mesh(new THREE.BoxGeometry(mode==='motes'?1.2:3,3,0.25),new THREE.MeshBasicMaterial({color:0x789589}));wall.position.set(0,1.5,mode==='motes'?0:-0.6);scene.add(wall);
  if(mode==='motes')for(const x of [-2.2,2.2]){const side=new THREE.Mesh(new THREE.BoxGeometry(0.15,3.4,12),material);side.position.set(x,1.6,0);scene.add(side);}
  const vfx=new ThreeVfxRenderer({scene,camera,captureDebugTransforms:true});
  let instance=null,disposed=false,last=performance.now(),elapsed=0,frameId;
  const normal=new THREE.Vector3(0,0,1),point=new THREE.Vector3(0,1.4,-0.46);
  const rotation=new THREE.Euler().setFromQuaternion(new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,0,1),normal));
  function spawn(){if(instance)vfx.removeEffect(instance,true);const effect=structuredClone(original);effect.emitters.forEach(e=>e.render.depthTest=document.querySelector('#depth').checked);instance=vfx.createEffect(effect,{position:mode==='snow'?[0,3.5,0]:mode==='motes'?[0,1.4,0]:point.clone().addScaledVector(normal,0.02).toArray(),rotation:[rotation.x,rotation.y,rotation.z],seed:42});}
  spawn();document.querySelector('#action').onclick=spawn;document.querySelector('#depth').onchange=spawn;
  function resize(){const width=host.clientWidth,height=host.clientHeight;renderer.setSize(width,height);camera.aspect=width/height;camera.updateProjectionMatrix();}
  const observer=new ResizeObserver(resize);observer.observe(host);resize();
  function frame(now){if(disposed)return;frameId=requestAnimationFrame(frame);const dt=Math.min((now-last)/1000,0.05);last=now;if(document.hidden)return;elapsed+=dt;vfx.update(dt);renderer.render(scene,camera);const transforms=instance.getParticleDebugTransforms();window.recipeState={mode,elapsed,depthTest:document.querySelector('#depth').checked,disposed,stats:{...vfx.stats},hostDrawCalls:renderer.info.render.calls,positions:transforms.slice(0,5).map(t=>t.position)};document.querySelector('#stats').textContent=JSON.stringify(window.recipeState,null,2);}
  frameId=requestAnimationFrame(frame);
  function dispose(){if(disposed)return;disposed=true;cancelAnimationFrame(frameId);observer.disconnect();vfx.destroy();const materials=new Set();scene.traverse(o=>{o.geometry?.dispose();if(o.material)materials.add(o.material);});materials.forEach(m=>m.dispose());renderer.dispose();document.querySelector('#action').disabled=true;document.querySelector('#depth').disabled=true;document.querySelector('#dispose').disabled=true;window.recipeState={mode,disposed:true};document.querySelector('#status').textContent='Disposed';}
  document.querySelector('#dispose').onclick=dispose;window.addEventListener('pagehide',dispose,{once:true});
  document.querySelector('#status').textContent='Ready';
}
