import {loadVfxExportBundle} from 'nixie-fx/export';
import manifest from '../vfx-project/out/vfx/manifest.json';
import hover from '../vfx-project/out/vfx/effects/hover-ember.json';
import snow from '../vfx-project/out/vfx/effects/snowfall.json';
import motes from '../vfx-project/out/vfx/effects/corridor-motes.json';
import impact from '../vfx-project/out/vfx/effects/wall-sparks.json';
export async function loadEffect(id,backend){
  const effectsByPath={'effects/hover-ember.json':hover,'effects/snowfall.json':snow,'effects/corridor-motes.json':motes,'effects/wall-sparks.json':impact};
  const bundle=loadVfxExportBundle({manifest,effectsByPath},{requiredBackend:backend,requiredEffectIds:[id]});
  const effect=bundle.effectsById.get(id);
  const entry=manifest.effects.find(e=>e.id===id);
  if(entry.support.backends[backend].status!=='supported')throw new Error(`Needs review: ${id} ${backend}`);
  return {effect,entry};
}
