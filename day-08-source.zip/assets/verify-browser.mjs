import {createRequire} from 'node:module';
import {writeFile,mkdir} from 'node:fs/promises';
const require=createRequire('/Users/almastparuyryan/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/package.json');
const {chromium}=require('playwright');
const UPNG=require('@pdf-lib/upng').default;
await mkdir('../evidence',{recursive:true});
const browser=await chromium.launch({headless:true,channel:'chrome'});
const records=[];
try {
  for(const viewport of [{width:1280,height:900},{width:390,height:844}]) {
    for(const mode of ['hover','snow','motes','impact']) {
      const page=await browser.newPage({viewport});const errors=[];
      page.on('pageerror',error=>errors.push(error.message));
      await page.goto(`http://127.0.0.1:5188/?mode=${mode}`);
      await page.waitForFunction(()=>document.querySelector('#status').textContent==='Ready');
      if(mode==='hover')await page.locator('#game-button').focus();
      if(mode==='impact')await page.locator('#action').click();
      await page.waitForTimeout(mode==='impact'?180:1800);
      const state=await page.evaluate(()=>window.recipeState);
      if(!state.stats.activeParticles)throw new Error(`No live particles: ${mode}`);
      const file=`../evidence/${mode}-${viewport.width}.png`;
      await page.screenshot({path:file,fullPage:true});
      const canvas=await page.locator('canvas').screenshot();
      const decoded=UPNG.decode(canvas.buffer.slice(canvas.byteOffset,canvas.byteOffset+canvas.byteLength));
      const pixels=new Uint8Array(UPNG.toRGBA8(decoded)[0]);const colors=new Set();
      for(let i=0;i<pixels.length;i+=16)colors.add(`${pixels[i]},${pixels[i+1]},${pixels[i+2]}`);
      if(colors.size<8)throw new Error(`Blank canvas: ${mode} ${viewport.width} ${colors.size}`);
      if(errors.length)throw new Error(errors.join('; '));
      const overflow=await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth);
      if(overflow)throw new Error(`Overflow: ${mode} ${viewport.width}`);
      if(mode==='hover') {
        await page.locator('#game-button').hover();await page.mouse.move(0,0);await page.waitForTimeout(100);
        if(!(await page.evaluate(()=>window.recipeState.focused&&window.recipeState.stats.activeParticles>0)))throw new Error('Pointer leave lost focused effect');
        await page.keyboard.press('Enter');
        await page.waitForFunction(()=>window.recipeState.activationCount===1);
        await page.locator('#dispose').focus();await page.waitForTimeout(900);
        const stopped=await page.evaluate(()=>window.recipeState.stats.activeParticles);
        if(stopped!==0)throw new Error(`Blur did not drain: ${stopped}`);
        await page.emulateMedia({reducedMotion:'reduce'});await page.locator('#game-button').focus();await page.waitForTimeout(200);
        if((await page.evaluate(()=>window.recipeState.stats.activeParticles))!==0)throw new Error('Reduced motion emitted');
      }
      if(mode==='snow') {
        const first=await page.evaluate(()=>window.recipeState.positions);
        await page.waitForTimeout(150);
        const second=await page.evaluate(()=>window.recipeState.positions);
        if(JSON.stringify(first)===JSON.stringify(second))throw new Error('Snow did not move');
      }
      if(mode==='motes') {
        await page.locator('#depth').uncheck();await page.waitForTimeout(1000);
        await page.screenshot({path:`../evidence/motes-no-depth-${viewport.width}.png`,fullPage:true});
      }
      if(mode==='impact') {
        await page.waitForTimeout(800);
        if((await page.evaluate(()=>window.recipeState.stats.activeParticles))!==0)throw new Error('Impact did not drain');
      }
      await page.locator('#dispose').click();
      if(!(await page.evaluate(()=>window.recipeState.disposed)))throw new Error('Teardown failed');
      records.push({viewport,mode,state,canvasColors:colors.size,errors,screenshot:file,teardown:true});
      await page.close();
    }
  }
  await writeFile('../evidence/browser-checks.json',JSON.stringify(records,null,2));
  console.log(records.map(r=>({mode:r.mode,width:r.viewport.width,particles:r.state.stats.activeParticles,canvasColors:r.canvasColors,teardown:r.teardown})));
} finally {await browser.close();}
