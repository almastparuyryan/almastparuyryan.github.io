import { readFile, writeFile, mkdir, cp } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { loadVfxExportBundle } from 'nixie-fx/export';
const template = JSON.parse(await readFile('starter-project.json', 'utf8'));
template.id = 'day08-particle-recipes'; template.name = 'Day 8 interaction and world effects';
template.settings.lastEffectFile = 'hover-ember.json';
await mkdir('vfx-project/effects', { recursive: true });
await mkdir('vfx-project/assets', { recursive: true });
await writeFile('vfx-project/vfx-editor.prj', JSON.stringify(template, null, 2));
function constant(value) { return { mode: 'constant', value, min: value, max: value, curve: [{x:0,y:value},{x:1,y:value}], curveB: [{x:0,y:value},{x:1,y:value}] }; }
const specs = [
  {id:'hover-ember', profile:'pixi-ui-2d', cap:24, life:0.65, rate:22, size:5, speed:0, color:[1,0.38,0.1,0.8], box:[176,56,0]},
  {id:'snowfall', profile:'three-world-3d', cap:96, life:4, rate:20, size:0.075, speed:0, color:[0.85,0.93,1,0.8], box:[7,0.1,6]},
  {id:'corridor-motes', profile:'three-world-3d', cap:32, life:4, rate:6, size:0.13, speed:0.03, color:[0.65,0.88,0.85,0.2], box:[3,2.2,8]},
  {id:'wall-sparks', profile:'three-world-3d', cap:24, life:0.55, rate:0, size:0.05, speed:2, color:[1,0.5,0.15,1], box:[0.015,0.015,0.015], burst:18}
];
for (const spec of specs) {
  const fx = JSON.parse(await readFile('starter-effect.json', 'utf8'));
  fx.id = spec.id; fx.name = spec.id; fx.targetProfile = spec.profile;
  fx.timeline.duration = spec.burst ? 0.7 : 5;
  const e = fx.emitters[0]; e.id = `${spec.id}-emitter`; e.name = spec.id;
  e.maxParticles = spec.cap; e.loop = !spec.burst; e.duration = spec.burst ? 0.05 : 1;
  e.spawn.rate = spec.rate; e.spawn.rateValue = constant(spec.rate);
  e.spawn.shape = 'box'; e.spawn.box = spec.box; e.spawn.radius = 0; e.spawn.radiusValue = constant(0);
  e.spawn.bursts = spec.burst ? [{time:0,count:spec.burst,cycles:1,interval:0,probability:1}] : [];
  e.initializeParticle.lifetime = constant(spec.life);
  e.initializeParticle.velocity.speed = constant(spec.speed);
  e.initializeParticle.color.color = spec.color; e.initializeParticle.color.colorB = spec.color;
  e.initializeParticle.size = constant(spec.size);
  e.billboard.sizeStart = spec.size; e.billboard.sizeEnd = spec.size; e.billboard.sizeValue = constant(spec.size);
  e.color.start = spec.color; e.color.end = [...spec.color.slice(0,3),0];
  e.color.gradient.colorStops = [{position:0,color:spec.color.slice(0,3)},{position:1,color:spec.color.slice(0,3)}];
  e.color.gradient.alphaStops = [{position:0,alpha:0},{position:0.15,alpha:1},{position:1,alpha:0}];
  e.render.depthTest = spec.profile !== 'pixi-ui-2d'; e.render.depthWrite = false; e.render.depthInk = false;
  if (spec.id === 'snowfall') {
    e.initializeParticle.velocity.mode = 'vector';
    e.initializeParticle.velocity.min = [0.06, -0.85, 0];
    e.initializeParticle.velocity.max = [0.12, -0.65, 0];
  }
  if (spec.id === 'hover-ember') {
    e.initializeParticle.velocity.mode = 'vector';
    e.initializeParticle.velocity.min = [-6, -22, 0];
    e.initializeParticle.velocity.max = [6, -12, 0];
  }
  if (spec.id === 'wall-sparks') {
    e.spawn.simulationSpace = 'local';
    e.initializeParticle.velocity.mode = 'vector';
    e.initializeParticle.velocity.min = [-0.8, -0.8, 1.2];
    e.initializeParticle.velocity.max = [0.8, 0.8, 2];
  }
  await writeFile(`vfx-project/effects/${spec.id}.json`, JSON.stringify(fx, null, 2));
}
const cli = fileURLToPath(new URL('./dist/cli.js', import.meta.resolve('nixie-fx/package.json')));
for (const action of ['validate', 'export']) {
  const result = spawnSync(process.execPath, [cli, action, './vfx-project'], {encoding:'utf8'});
  console.log(result.stdout, result.stderr);
  if (result.status !== 0) process.exit(result.status || 1);
}
await mkdir('public/vfx', {recursive:true});
await cp('vfx-project/out/vfx', 'public/vfx', {recursive:true});
const manifest = JSON.parse(await readFile('public/vfx/manifest.json', 'utf8'));
const effectsByPath = Object.fromEntries(await Promise.all(manifest.effects.map(async entry => [entry.path, JSON.parse(await readFile(`public/vfx/${entry.path}`, 'utf8'))])));
const bundle = loadVfxExportBundle({manifest,effectsByPath});
const report = manifest.effects.map(e => ({id:e.id,support:e.support}));
await mkdir('../evidence', {recursive:true});
await writeFile('../evidence/export-check.json', JSON.stringify({effectCount:bundle.effectsById.size,report}, null, 2));
console.log(report.map(e => [e.id,e.support.backends.pixi2d.status,e.support.backends.three3d.status]));
