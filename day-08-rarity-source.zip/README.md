# N-353: fixed inventory geometry while assets load

Day 8 follow-up after the user corrected NixieFX row 40 from Day 16.

Pinned PixiJS 8.19.0, nixie-fx 0.1.17, Vite 8.3.1. This is a synthetic inventory fixture, not a production game or performance benchmark. The 900 ms delay is artificial and happens after asset loading.

```sh
npm ci
node prepare-effects.mjs
npm run dev -- --port 5192
npm run build
```

`prepare-effects.mjs` derives the two non-looping effects from the included starter files and exports them for the `pixi2d` backend. Export validation has zero errors and warnings. The intentionally absent `day-08-rarity-missing.svg` tests error handling; do not create it.

`evidence/browser-checks.json` contains desktop (1280 x 1000) and mobile (390 x 1000) DOM/runtime observations for loading, reveal, missing asset, retry ordering, reduced motion, and disposal during a delayed completion. Geometry baselines reset on intentional stage-size changes. Screenshot captures pause the effects mid-burst. Source includes geometry measurements and scene lifecycle logic; no credentials or account state are included.

Supported here: exported 2D billboards, box emitters, burst count, lifetime fade, sprite positioning, reduced-motion suppression. This fixture does not validate custom materials, trails, lights, or 3D depth/lighting. Those omissions are not package-wide unsupported-feature claims.

Local development uses a symlink to the existing Day 8 dependencies; the downloadable archive excludes node_modules and can be installed with npm ci.
