import './style.css';
import {Application,Assets,Container,Sprite,Texture} from 'pixi.js';
import {PixiVfxRenderer,createPixiVfx2dProjection} from 'nixie-fx/pixi';
import {loadVfxExportBundle} from 'nixie-fx/export';
import manifest from '../vfx-project/out/vfx/manifest.json';
import rare from '../vfx-project/out/vfx/effects/rare-reveal.json';
import epic from '../vfx-project/out/vfx/effects/epic-reveal.json';

const stage=document.querySelector('#stage'),status=document.querySelector('#status'),stats=document.querySelector('#stats');
const loadButton=document.querySelector('#load'),disposeButton=document.querySelector('#dispose');
const reduced=document.querySelector('#reduced'),paused=document.querySelector('#paused');
const reduceMotion=()=>motion.matches||reduced.checked;
const cards=[...document.querySelectorAll('.item-card')];
const assetUrl=new URL('./day-08-rarity-relic.svg',document.baseURI).href;
const missingUrl=new URL('./day-08-rarity-missing.svg',document.baseURI).href;
const app=new Application();
const live=new Map(),sprites=new Map(),pending=new Set(),motion=matchMedia('(prefers-reduced-motion: reduce)');
let vfx,disposed=false,generation=0,staleLoadsIgnored=0,assetState='loading',revealCount=0,baseline,maxBoundsDelta=0,anchorError=0,lastSize='',cleanupComplete=false;
const records=[];
function rects(){const s=stage.getBoundingClientRect();return cards.map(c=>{const b=c.getBoundingClientRect(),slot=c.querySelector('.item-slot').getBoundingClientRect();return {id:c.dataset.item,x:b.x-s.x,y:b.y-s.y,pageX:b.x+scrollX,pageY:b.y+scrollY,width:b.width,height:b.height,slotX:slot.x-s.x,slotY:slot.y-s.y,slotWidth:slot.width,slotHeight:slot.height};});}
function setCardState(text,ready){for(const c of cards){c.querySelector('.item-state').textContent=text;c.querySelector('.asset-state').hidden=ready;c.querySelector('.asset-state').textContent=text;c.querySelector('.reveal').disabled=!ready||disposed;}}
function clearEffects(){for(const fx of live.values())vfx.removeEffect(fx,true);live.clear();}
function snapshot(event){const data={event,generation,assetState,staleLoadsIgnored,revealCount,disposed,cleanupComplete,reducedMotion:reduceMotion(),paused:paused.checked,maxBoundsDelta:+maxBoundsDelta.toFixed(4),anchorError:+anchorError.toFixed(4),cards:rects(),stats:disposed?null:{...vfx.stats}};stats.textContent=JSON.stringify(data,null,2);if(event!=='frame'){records.push(data);if(records.length>40)records.shift();document.querySelector('#events').textContent=JSON.stringify(records,null,2);}return data;}
async function loadItems(){
  if(disposed)return;
  const token=++generation,fail=document.querySelector('#missing').checked,delay=document.querySelector('#delay').checked;
  clearEffects();assetState='loading';setCardState('Asset loading',false);for(const s of sprites.values())s.visible=false;status.textContent='Loading';snapshot('load-start');
  const request=Assets.load(fail?missingUrl:assetUrl);pending.add(request);request.then(()=>pending.delete(request),()=>pending.delete(request));
  try{
    const texture=await request;if(delay)await new Promise(resolve=>setTimeout(resolve,900));
    // Late completions may update diagnostics, never a superseded or destroyed scene.
    if(disposed||token!==generation){staleLoadsIgnored++;snapshot('stale-load-ignored');return;}
    if(!(texture instanceof Texture))throw new Error('The asset did not resolve to a texture');
    for(const s of sprites.values()){s.texture=texture;s.width=96;s.height=96;s.visible=true;}
    assetState='ready';setCardState('Asset ready',true);status.textContent='Ready';snapshot('load-ready');
  }catch(error){
    if(disposed||token!==generation){staleLoadsIgnored++;return;}
    assetState='error';setCardState('Asset unavailable',false);status.textContent='Asset load failed';snapshot('load-error');
  }
}
function reveal(id){
  if(disposed||assetState!=='ready')return;
  if(live.has(id)){vfx.removeEffect(live.get(id),true);live.delete(id);}
  revealCount++;if(!reduceMotion()){const card=cards.find(c=>c.dataset.item===id),p=card.querySelector('.item-slot').getBoundingClientRect(),s=stage.getBoundingClientRect();live.set(id,vfx.createEffect(bundle.effectsById.get(id+'-reveal'),{position:[p.x-s.x+p.width/2,p.y-s.y+p.height/2,0],seed:42}));}
  cards.find(c=>c.dataset.item===id).querySelector('.item-state').textContent=reduceMotion()?'Revealed (static)':'Revealed';snapshot('reveal');
}
function tick(t){
  if(disposed||document.hidden)return;
  const current=rects(),size=stage.clientWidth+'x'+stage.clientHeight;
  if(lastSize!==size){lastSize=size;baseline=current;maxBoundsDelta=0;}
  anchorError=0;
  current.forEach((r,i)=>{
    const x=r.slotX+r.slotWidth/2,y=r.slotY+r.slotHeight/2,sprite=sprites.get(r.id);sprite.position.set(x,y);
    const fx=live.get(r.id);if(fx){fx.setPosition([x,y,0]);if(!fx.isActive){vfx.removeEffect(fx,true);live.delete(r.id);}}
    if(sprite.visible){const b=sprite.getBounds();anchorError=Math.max(anchorError,Math.abs(b.x+b.width/2-x),Math.abs(b.y+b.height/2-y));}
    for(const key of ['x','y','pageX','pageY','width','height','slotX','slotY','slotWidth','slotHeight'])maxBoundsDelta=Math.max(maxBoundsDelta,Math.abs(r[key]-baseline[i][key]));
  });
  if(!paused.checked)vfx.update(Math.min(t.deltaMS/1000,.05));snapshot('frame');
}
function motionChange(){if(reduceMotion())clearEffects();}
async function dispose(){
  if(disposed)return;disposed=true;generation++;app.ticker.remove(tick);motion.removeEventListener('change',motionChange);clearEffects();vfx.destroy();app.destroy(true,{children:true,texture:false,textureSource:false});
  loadButton.disabled=true;disposeButton.disabled=true;reduced.disabled=true;paused.disabled=true;setCardState('Disposed',false);status.textContent='Disposed';snapshot('dispose');
  await Promise.allSettled([...pending]);await Assets.unload(assetUrl);cleanupComplete=true;snapshot('cleanup-complete');
}
const bundle=loadVfxExportBundle({manifest,effectsByPath:{'effects/rare-reveal.json':rare,'effects/epic-reveal.json':epic}},{requiredBackend:'pixi2d'});
async function init(){
  await app.init({resizeTo:stage,backgroundAlpha:0,antialias:true,resolution:Math.min(devicePixelRatio,2),autoDensity:true,preference:'webgl'});stage.append(app.canvas);
  const effectLayer=new Container(),itemLayer=new Container();app.stage.addChild(effectLayer,itemLayer);
  vfx=new PixiVfxRenderer({parent:effectLayer,projection:createPixiVfx2dProjection({pixelsPerUnit:1,yAxis:'down'})});
  for(const c of cards){const s=new Sprite(Texture.EMPTY);s.anchor.set(.5);s.visible=false;s.tint=c.dataset.item==='rare'?0xffffff:0xf8d8ec;itemLayer.addChild(s);sprites.set(c.dataset.item,s);c.querySelector('.reveal').onclick=()=>reveal(c.dataset.item);}
  app.ticker.add(tick);motion.addEventListener('change',motionChange);reduced.onchange=motionChange;loadButton.onclick=loadItems;disposeButton.onclick=()=>void dispose();loadButton.disabled=false;disposeButton.disabled=false;
  window.addEventListener('pagehide',()=>void dispose(),{once:true});await loadItems();
}
init().catch(error=>{status.textContent='Initialization failed: '+error.message;console.error(error);});
