import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {loadVfxExportBundle} from 'nixie-fx/export';
const project=JSON.parse(await readFile('starter-project.json','utf8'));
project.id='day08-rarity-loading';project.name='Rarity loading and geometry proof';project.settings.lastEffectFile='rare-reveal.json';
await mkdir('vfx-project/effects',{recursive:true});await mkdir('vfx-project/assets',{recursive:true});
await writeFile('vfx-project/vfx-editor.prj',JSON.stringify(project,null,2));
const constant=value=>({mode:'constant',value,min:value,max:value,curve:[{x:0,y:value},{x:1,y:value}],curveB:[{x:0,y:value},{x:1,y:value}]});
for(const spec of [{id:'rare-reveal',count:12,color:[.16,.64,.89,1]},{id:'epic-reveal',count:20,color:[.92,.35,.5,1]}]){
  const fx=JSON.parse(await readFile('starter-effect.json','utf8'));
  fx.id=spec.id;fx.name=spec.id;fx.targetProfile='pixi-ui-2d';fx.timeline.duration=.9;
  const e=fx.emitters[0];e.id=spec.id+'-emitter';e.name=spec.id;e.maxParticles=24;e.loop=false;e.duration=.05;
  e.spawn.rate=0;e.spawn.rateValue=constant(0);e.spawn.shape='box';e.spawn.box=[78,78,0];e.spawn.radius=0;e.spawn.radiusValue=constant(0);
  e.spawn.bursts=[{time:0,count:spec.count,cycles:1,interval:0,probability:1}];e.spawn.simulationSpace='local';
  e.initializeParticle.lifetime=constant(.75);e.initializeParticle.size=constant(5);
  e.initializeParticle.velocity.mode='vector';e.initializeParticle.velocity.min=[-30,-38,0];e.initializeParticle.velocity.max=[30,12,0];e.initializeParticle.velocity.speed=constant(0);
  e.initializeParticle.color.color=spec.color;e.initializeParticle.color.colorB=spec.color;
  e.billboard.sizeStart=5;e.billboard.sizeEnd=5;e.billboard.sizeValue=constant(5);
  e.color.start=spec.color;e.color.end=[...spec.color.slice(0,3),0];e.color.gradient.colorStops=[{position:0,color:spec.color.slice(0,3)},{position:1,color:spec.color.slice(0,3)}];e.color.gradient.alphaStops=[{position:0,alpha:0},{position:.12,alpha:1},{position:1,alpha:0}];
  e.render.depthTest=false;e.render.depthWrite=false;e.render.depthInk=false;
  await writeFile(`vfx-project/effects/${spec.id}.json`,JSON.stringify(fx,null,2));
}
const cli=fileURLToPath(new URL('./dist/cli.js',import.meta.resolve('nixie-fx/package.json')));
for(const command of ['validate','export']){const r=spawnSync(process.execPath,[cli,command,'vfx-project'],{encoding:'utf8'});console.log(r.stdout,r.stderr);if(r.status)process.exit(r.status);}
const manifest=JSON.parse(await readFile('vfx-project/out/vfx/manifest.json','utf8'));
const effectsByPath=Object.fromEntries(await Promise.all(manifest.effects.map(async e=>[e.path,JSON.parse(await readFile('vfx-project/out/vfx/'+e.path,'utf8'))])));
const bundle=loadVfxExportBundle({manifest,effectsByPath},{requiredBackend:'pixi2d'});
await mkdir('evidence',{recursive:true});await writeFile('evidence/export-check.json',JSON.stringify({effects:bundle.effectsById.size,support:manifest.effects.map(e=>({id:e.id,support:e.support}))},null,2));
