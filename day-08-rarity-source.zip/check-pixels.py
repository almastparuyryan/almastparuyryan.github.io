import json
from pathlib import Path
from PIL import Image

root = Path(__file__).resolve().parent / 'evidence'
checks = json.loads((root / 'browser-checks.json').read_text())
results = []
for filename, event in [('desktop-reveal.jpg', 'desktop-reveal-paused'),
                        ('mobile-reveal.jpg', 'mobile-reveal-paused')]:
    record = next(row for row in checks if row['label'] == event)
    cards = record['cards']
    left = min(c['pageX'] for c in cards)
    top = min(c['pageY'] for c in cards)
    right = max(c['pageX'] + c['width'] for c in cards)
    bottom = max(c['pageY'] + c['height'] for c in cards)
    box = tuple(round(value) for value in (left, top, right, bottom))
    image = Image.open(root / filename).convert('RGB')
    colors = image.crop(box).getcolors(image.width * image.height)
    colored = sum(n for n, (r, g, b) in colors if max(r, g, b) - min(r, g, b) > 35)
    result = {'file': filename, 'region': box, 'uniqueColors': len(colors),
              'chromaticPixels': colored, 'nonblank': colored > 500}
    assert result['nonblank'], result
    results.append(result)
(root / 'pixel-checks.json').write_text(json.dumps(results, indent=2))
print(json.dumps(results, indent=2))
