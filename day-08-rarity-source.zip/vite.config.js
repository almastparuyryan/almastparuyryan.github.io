import {defineConfig} from 'vite';
export default defineConfig({base:'./', build:{rollupOptions:{output:{entryFileNames:'rarity-[hash].js',chunkFileNames:'rarity-[name]-[hash].js',assetFileNames:'rarity-[name]-[hash][extname]'}}}});
