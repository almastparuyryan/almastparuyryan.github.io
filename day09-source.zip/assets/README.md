# Day 9 NixieFX runtime examples

Four synthetic fixtures support five distinct drafts. Dependencies are pinned: NixieFX 0.1.17, PixiJS 8.19.0, Three.js 0.185.1, and Vite 8.3.1. They are reproducible examples, not production gameplay or performance benchmarks.

## Run

```sh
npm install
npm run prepare-effects
npm run dev -- --port 5189
```

Open the local preview at `http://127.0.0.1:5189` with `?mode=aura`, `?mode=ember`, `?mode=ring`, or `?mode=smoke`. `npm run build` produces the static deployment folder `dist/`. Nothing in this preparation publishes that folder.

The local workspace uses a symlink to already installed packages. The source archive excludes this symlink; recipients install the pinned dependencies themselves. The project includes its starter definitions, authoring files, compiled exports, source code, and third-party notices.

## Effect contracts

- Aura: 12 particles/second, 1.4-second lifetime, cap 20. A 13.2 by 11.6-unit box projects to 132 by 116 pixels at ten pixels/unit. The host clips the particle region to 136 by 120 pixels. An opaque portrait occupies its center; the dialogue panel is separate. A static label preserves speaker state when reduced motion disables decoration.
- Ember: 16 particles/second, 0.6-second lifetime, cap 16. A native button keeps hover, focus, disabled state, and activation separate. The 18.8 by 7-unit box projects to 188 by 70 pixels. Enter and Space retain native semantics; particles stop on blur, disable, and reduced motion.
- Ring: one burst of 40, 0.85-second lifetime, cap 48. Circle emission lies in XZ, radius 1, zero thickness; world origin `[1, 0.04, -0.5]`. Cameras: oblique, top, low. Uniform scales: 0.5, 1, 2. Rendered world centers are measured from each debug matrix and the instance root world matrix, rather than unscaled sample positions.
- Smoke: 12 particles/second, three-second lifetime, cap 40. Unlit billboards rise and spread from a stationary local-space source. There is no fluid simulation, physical lighting, collision, or shadowing.

The PixiJS fixtures use ten pixels per authoring unit, including conversion of host pixel positions back to scene units. This avoids the runtime's box-axis normalization limit of 48 units. The Three.js fixtures use depth testing but no depth writing; PixiJS depth settings do not imply GPU depth-buffer occlusion.

## Verification

`npm run prepare-effects` validates and exports all four effects, then saves their backend reports to `../evidence/export-check.json`. The definitions are supported on their intended backends.

`verify-browser.mjs` uses this machine's bundled Playwright and installed Chrome. Run it locally with `node verify-browser.mjs` after starting the preview on port 5189. The script records runtime counts, keyboard activation, reduced motion, disabled behavior, visible aura pixels, identical dialogue-panel pixels, ring scale/camera measurements, smoke movement, and teardown. It also captures actual screenshots at viewport widths 1280 and 390. Its bundled-library path is machine-specific; adapt the `createRequire` path to your installed Playwright if running elsewhere.

The evidence is functional and visual. It does not measure target-device frame times, certify accessibility, audit memory, or prove behavior in a different engine version.
