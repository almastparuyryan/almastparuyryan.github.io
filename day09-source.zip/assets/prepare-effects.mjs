import {readFile,writeFile,mkdir,cp} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {loadVfxExportBundle} from 'nixie-fx/export';
const project=JSON.parse(await readFile('starter-project.json','utf8'));
project.id='day09-effects';project.name='Dialogue aura, ember, landing ring and smoke';project.settings.lastEffectFile='portrait-aura.json';
await mkdir('vfx-project/effects',{recursive:true});await mkdir('vfx-project/assets',{recursive:true});
await writeFile('vfx-project/vfx-editor.prj',JSON.stringify(project,null,2));
const constant=value=>({mode:'constant',value,min:value,max:value,curve:[{x:0,y:value},{x:1,y:value}],curveB:[{x:0,y:value},{x:1,y:value}]});
const specs=[
 {id:'portrait-aura',profile:'pixi-ui-2d',rate:12,life:1.4,cap:20,size:0.8,color:[0.4,0.75,1,0.65],box:[13.2,11.6,0],vmin:[-0.2,-0.6,0],vmax:[0.2,-0.3,0]},
 {id:'focus-ember',profile:'pixi-ui-2d',rate:16,life:0.6,cap:16,size:0.5,color:[1,0.4,0.1,0.85],box:[18.8,7,0],vmin:[-0.4,-2,0],vmax:[0.4,-1.2,0]},
 {id:'landing-ring',profile:'three-world-3d',rate:0,life:0.85,cap:48,size:0.12,color:[0.25,0.8,1,0.9],box:[0,0,0],vmin:[0,0.08,0],vmax:[0,0.08,0],burst:40},
 {id:'smoke-plume',profile:'three-world-3d',rate:12,life:3,cap:40,size:0.65,color:[0.6,0.65,0.7,0.24],box:[0.4,0.1,0.4],vmin:[-0.12,0.65,-0.12],vmax:[0.12,0.85,0.12]}
];
for(const s of specs){
 const fx=JSON.parse(await readFile('starter-effect.json','utf8'));fx.id=s.id;fx.name=s.id;fx.targetProfile=s.profile;fx.timeline.duration=s.burst?1.1:5;
 const e=fx.emitters[0];e.id=s.id+'-emitter';e.name=s.id;e.maxParticles=s.cap;e.loop=!s.burst;e.duration=s.burst?0.05:1;
 e.spawn.shape='box';e.spawn.box=s.box;e.spawn.radius=0;e.spawn.radiusValue=constant(0);e.spawn.simulationSpace='local';e.spawn.rate=s.rate;e.spawn.rateValue=constant(s.rate);e.spawn.bursts=s.burst?[{time:0,count:s.burst,cycles:1,interval:0,probability:1}]:[];
 e.initializeParticle.lifetime=constant(s.life);e.initializeParticle.size=constant(s.size);e.initializeParticle.velocity.mode='vector';e.initializeParticle.velocity.min=s.vmin;e.initializeParticle.velocity.max=s.vmax;e.initializeParticle.velocity.speed=constant(0);
 e.initializeParticle.color.color=s.color;e.initializeParticle.color.colorB=s.color;e.billboard.sizeStart=s.size;e.billboard.sizeEnd=s.size;e.billboard.sizeValue=constant(s.size);
 e.color.start=s.color;e.color.end=[...s.color.slice(0,3),0];e.color.gradient.colorStops=[{position:0,color:s.color.slice(0,3)},{position:1,color:s.color.slice(0,3)}];e.color.gradient.alphaStops=[{position:0,alpha:0},{position:0.12,alpha:s.color[3]},{position:1,alpha:0}];
 e.render.depthTest=s.profile==='three-world-3d';e.render.depthWrite=false;e.render.depthInk=false;e.render.blend='alpha';
 if(s.id==='landing-ring'){e.spawn.shape='circle';e.spawn.radius=1;e.spawn.radiusValue=constant(1);e.spawn.radiusThickness=0;e.spawn.rotation=[0,0,0];}
 await writeFile(`vfx-project/effects/${s.id}.json`,JSON.stringify(fx,null,2));
}
const cli=fileURLToPath(new URL('./dist/cli.js',import.meta.resolve('nixie-fx/package.json')));
for(const action of ['validate','export']){const r=spawnSync(process.execPath,[cli,action,'./vfx-project'],{encoding:'utf8'});console.log(r.stdout,r.stderr);if(r.status)process.exit(r.status);}
await mkdir('public/vfx',{recursive:true});await cp('vfx-project/out/vfx','public/vfx',{recursive:true});
const manifest=JSON.parse(await readFile('public/vfx/manifest.json','utf8'));
const effectsByPath=Object.fromEntries(await Promise.all(manifest.effects.map(async e=>[e.path,JSON.parse(await readFile('public/vfx/'+e.path,'utf8'))])));
const bundle=loadVfxExportBundle({manifest,effectsByPath});
await writeFile('../evidence/export-check.json',JSON.stringify({effectCount:bundle.effectsById.size,report:manifest.effects.map(e=>({id:e.id,support:e.support}))},null,2));
console.log('Validated effects:',[...bundle.effectsById.keys()]);
