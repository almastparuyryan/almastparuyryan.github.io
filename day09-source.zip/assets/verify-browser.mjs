import {createRequire} from 'node:module';import {writeFile} from 'node:fs/promises';import {createHash} from 'node:crypto';
const require=createRequire('/Users/almastparuyryan/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/package.json');
const {chromium}=require('playwright');const UPNG=require('@pdf-lib/upng').default;
const browser=await chromium.launch({headless:true,channel:'chrome'}),records=[];
const assert=(value,message)=>{if(!value)throw new Error(message)};
try{
 for(const width of [1280,390])for(const mode of ['aura','ember','ring','smoke']){
  const page=await browser.newPage({viewport:{width,height:900}}),errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.goto(`http://127.0.0.1:5189/?mode=${mode}`);await page.waitForFunction(()=>document.querySelector('#status').textContent==='Ready');
  if(mode==='ember')await page.locator('#game-button').focus();
  if(mode==='ring')await page.locator('#action').click();
  await page.waitForTimeout(mode==='ring'?200:1600);
  const state=await page.evaluate(()=>window.recipeState);assert(state.stats.activeParticles>0,`${mode} has no particles`);assert(state.stats.unsupportedFeatures.length===0,'Unsupported features');
  const screen=`../evidence/${mode}-${width}.png`;await page.screenshot({path:screen,fullPage:true});
  const canvas=await page.locator('canvas').screenshot();const dec=UPNG.decode(canvas.buffer.slice(canvas.byteOffset,canvas.byteOffset+canvas.byteLength));const pix=new Uint8Array(UPNG.toRGBA8(dec)[0]);const colors=new Set();for(let i=0;i<pix.length;i+=16)colors.add(`${pix[i]},${pix[i+1]},${pix[i+2]}`);assert(colors.size>8,`${mode} canvas blank`);
  const checks={};
  if(mode==='aura'){
   const before=await page.locator('#dialogue').screenshot();await page.locator('#action').click();await page.waitForTimeout(100);const after=await page.locator('#dialogue').screenshot();
   const roi=await page.evaluate(()=>{const b=document.querySelector('#portrait').getBoundingClientRect(),s=document.querySelector('#stage').getBoundingClientRect();return {x:Math.floor(b.left-s.left),y:Math.floor(b.top-s.top),w:136,h:120}});
   const offCanvas=await page.locator('canvas').screenshot();const offDec=UPNG.decode(offCanvas.buffer.slice(offCanvas.byteOffset,offCanvas.byteOffset+offCanvas.byteLength));const offPixels=new Uint8Array(UPNG.toRGBA8(offDec)[0]);let changed=0;for(let y=roi.y;y<roi.y+roi.h;y++)for(let x=roi.x;x<roi.x+roi.w;x++){const i=(y*dec.width+x)*4;if(pix[i]!==offPixels[i]||pix[i+1]!==offPixels[i+1]||pix[i+2]!==offPixels[i+2])changed++;}checks.auraRegionChangedPixels=changed;assert(changed>20,'Aura has no visible pixels outside the portrait');
   checks.textPixelsEqual=before.equals(after);checks.textImageHash=createHash('sha256').update(before).digest('hex');assert(checks.textPixelsEqual,'Dialogue pixels changed with aura');
   checks.pausedParticles=await page.evaluate(()=>window.recipeState.stats.activeParticles);assert(checks.pausedParticles===0,'Paused aura persisted');
   await page.screenshot({path:`../evidence/aura-off-${width}.png`,fullPage:true});await page.locator('#action').click();await page.waitForTimeout(300);
   await page.emulateMedia({reducedMotion:'reduce'});await page.waitForTimeout(100);checks.reducedMotionParticles=await page.evaluate(()=>window.recipeState.stats.activeParticles);assert(checks.reducedMotionParticles===0,'Reduced motion aura');
  }
  if(mode==='ember'){
   await page.locator('#game-button').hover();await page.mouse.move(0,0);await page.waitForTimeout(100);assert(await page.evaluate(()=>window.recipeState.focused&&window.recipeState.stats.activeParticles>0),'Pointer leave lost focus cue');
   await page.keyboard.press('Enter');await page.waitForFunction(()=>window.recipeState.activationCount===1);await page.keyboard.press('Space');await page.waitForFunction(()=>window.recipeState.activationCount===2);checks.keyboardActivations=2;
   await page.locator('#dispose').focus();await page.waitForTimeout(100);checks.blurParticles=await page.evaluate(()=>window.recipeState.stats.activeParticles);assert(checks.blurParticles===0,'Blur emission');
   await page.locator('#game-button').focus();await page.waitForTimeout(200);await page.locator('#action').click();await page.waitForTimeout(100);checks.disabledParticles=await page.evaluate(()=>window.recipeState.stats.activeParticles);assert(checks.disabledParticles===0,'Disabled emission');
   await page.locator('#action').click();await page.emulateMedia({reducedMotion:'reduce'});await page.locator('#game-button').focus();await page.waitForTimeout(100);checks.reducedMotionParticles=await page.evaluate(()=>window.recipeState.stats.activeParticles);assert(checks.reducedMotionParticles===0,'Reduced motion emission');
  }
  if(mode==='ring'){
   checks.matrix=[];
   for(const camera of ['oblique','top','low'])for(const scale of ['0.5','1','2']){
    await page.locator('#camera').selectOption(camera);await page.locator('#scale').selectOption(scale);await page.locator('#action').click();await page.waitForTimeout(180);
    const s=await page.evaluate(()=>window.recipeState);assert(s.stats.activeParticles===40,'Ring burst count');
    const points=s.positions;const radius=points.map(p=>Math.hypot(p[0]-1,p[2]+0.5));const err=Math.max(...radius.map(r=>Math.abs(r-Number(scale))));assert(err<0.001,`Ring radius error ${err}`);
    checks.matrix.push({camera,scale:Number(scale),particles:s.stats.activeParticles,maxRadiusError:err,yRange:[Math.min(...points.map(p=>p[1])),Math.max(...points.map(p=>p[1]))]});
    if(scale==='1')await page.screenshot({path:`../evidence/ring-${camera}-${width}.png`,fullPage:true});
   }
   await page.waitForTimeout(1000);checks.completedParticles=await page.evaluate(()=>window.recipeState.stats.activeParticles);assert(checks.completedParticles===0,'Ring did not complete');
  }
  if(mode==='smoke'){
   const a=state.positions;await page.waitForTimeout(150);const b=await page.evaluate(()=>window.recipeState.positions);checks.moved=JSON.stringify(a)!==JSON.stringify(b);assert(checks.moved,'Smoke stationary');assert(state.stats.capacity===40,'Smoke budget');
  }
  assert(!await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),'Page overflow');assert(errors.length===0,errors.join('; '));
  await page.locator('#dispose').click();assert(await page.evaluate(()=>window.recipeState.disposed),'Disposal failed');
  records.push({width,mode,state,checks,canvasColors:colors.size,errors,screenshot:screen,teardown:true});await page.close();
 }
 await writeFile('../evidence/browser-checks.json',JSON.stringify(records,null,2));console.log(records.map(r=>({mode:r.mode,width:r.width,particles:r.state.stats.activeParticles,checks:r.checks})));
}finally{await browser.close()}
