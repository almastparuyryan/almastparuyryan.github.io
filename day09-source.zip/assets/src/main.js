import './style.css';import {runPixi} from './pixi.js';import {runThree} from './three.js';
const labels={aura:'Keep dialogue particles inside the portrait',ember:'Hover and focus are separate inputs',ring:'Place a landing ring in world space',smoke:'A smoke plume made of unlit billboards'};
const chosen=new URLSearchParams(location.search).get('mode')||'aura';const mode=labels[chosen]?chosen:'aura';
document.querySelector('#title').textContent=labels[mode];
Promise.resolve(['aura','ember'].includes(mode)?runPixi(mode):runThree(mode)).catch(e=>{document.querySelector('#status').textContent=e.message;console.error(e)});
