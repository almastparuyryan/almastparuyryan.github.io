import * as THREE from 'three';import {ThreeVfxRenderer} from 'nixie-fx/three';import {loadEffect} from './bundle.js';
export async function runThree(mode){
 const {effect}=await loadEffect(mode==='ring'?'landing-ring':'smoke-plume','three3d');
 const stage=document.querySelector('#stage'),scene=new THREE.Scene();scene.background=new THREE.Color(0x14262b);
 const camera=new THREE.PerspectiveCamera(50,1,0.1,50),target=new THREE.Vector3(1,mode==='ring'?0:1.4,-0.5);
 const renderer=new THREE.WebGLRenderer({antialias:true,preserveDrawingBuffer:true});renderer.setPixelRatio(Math.min(devicePixelRatio,2));stage.append(renderer.domElement);
 const floor=new THREE.Mesh(new THREE.BoxGeometry(10,0.1,10),new THREE.MeshBasicMaterial({color:0x30444b}));floor.position.y=-0.05;scene.add(floor);
 const grid=new THREE.GridHelper(10,10,0x66858c,0x465d64);grid.position.y=0.003;scene.add(grid);
 const marker=new THREE.Mesh(new THREE.CylinderGeometry(0.12,0.12,0.08,24),new THREE.MeshBasicMaterial({color:0xc9dbcc}));marker.position.set(1,0.04,-0.5);scene.add(marker);
 const vfx=new ThreeVfxRenderer({scene,camera,captureDebugTransforms:true});
 let instance=null,disposed=false,last=performance.now(),frameId;
 function spawn(){if(instance)vfx.removeEffect(instance,true);const scale=Number(document.querySelector('#scale').value);instance=vfx.createEffect(effect,{position:[1,0.04,-0.5],scale:[scale,scale,scale],seed:42});}
 function setCamera(){const view=document.querySelector('#camera').value;camera.position.copy(target).add(new THREE.Vector3(...({oblique:[4,3,5],top:[0.01,8,0.01],low:[0,0.6,6]}[view])));camera.lookAt(target);camera.updateMatrixWorld();}
 spawn();setCamera();document.querySelector('#action').onclick=spawn;document.querySelector('#scale').onchange=spawn;document.querySelector('#camera').onchange=setCamera;
 const resize=()=>{renderer.setSize(stage.clientWidth,stage.clientHeight);camera.aspect=stage.clientWidth/stage.clientHeight;camera.updateProjectionMatrix()};const observer=new ResizeObserver(resize);observer.observe(stage);resize();
 function frame(now){if(disposed)return;frameId=requestAnimationFrame(frame);const dt=Math.min((now-last)/1000,0.05);last=now;if(document.hidden)return;vfx.update(dt);renderer.render(scene,camera);
  // Debug sample positions precede the root scale. Inspect actual render matrices in world space.
  const positions=instance.getParticleDebugTransforms().map(t=>new THREE.Vector3().setFromMatrixPosition(new THREE.Matrix4().fromArray(t.matrix)).applyMatrix4(instance.root.matrixWorld).toArray());
  window.recipeState={mode,camera:document.querySelector('#camera').value,scale:Number(document.querySelector('#scale').value),origin:[1,0.04,-0.5],disposed,stats:{...vfx.stats},positions,hostDrawCalls:renderer.info.render.calls};document.querySelector('#stats').textContent=JSON.stringify({...window.recipeState,positions:positions.slice(0,5)},null,2);
 }
 frameId=requestAnimationFrame(frame);
 function dispose(){if(disposed)return;disposed=true;cancelAnimationFrame(frameId);observer.disconnect();vfx.destroy();const materials=new Set();scene.traverse(o=>{o.geometry?.dispose();if(o.material)(Array.isArray(o.material)?o.material:[o.material]).forEach(m=>materials.add(m))});materials.forEach(m=>m.dispose());renderer.dispose();for(const id of ['action','camera','scale','dispose'])document.querySelector('#'+id).disabled=true;window.recipeState={mode,disposed:true};document.querySelector('#status').textContent='Disposed';}
 document.querySelector('#dispose').onclick=dispose;window.addEventListener('pagehide',dispose,{once:true});document.querySelector('#status').textContent='Ready';
}
