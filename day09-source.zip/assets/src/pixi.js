import {Application,Container,Graphics} from 'pixi.js';
import {PixiVfxRenderer,createPixiVfx2dProjection} from 'nixie-fx/pixi';import {loadEffect} from './bundle.js';
export async function runPixi(mode){
 const {effect}=await loadEffect(mode==='aura'?'portrait-aura':'focus-ember','pixi2d');
 const stage=document.querySelector('#stage'),button=document.querySelector('#game-button'),portrait=document.querySelector('#portrait'),dialogue=document.querySelector('#dialogue');
 const app=new Application();await app.init({resizeTo:stage,background:0x14262b,antialias:true});stage.prepend(app.canvas);
 const layer=new Container();app.stage.addChild(layer);const mask=new Graphics();app.stage.addChild(mask);if(mode==='aura')layer.mask=mask;
 const pixelsPerUnit=10;
 const vfx=new PixiVfxRenderer({parent:layer,projection:createPixiVfx2dProjection({pixelsPerUnit,yAxis:'down'})});
 let instance=null,hovered=false,focused=false,speaking=true,activationCount=0,disposed=false;
 const motion=matchMedia('(prefers-reduced-motion: reduce)');
 function sync(){const active=(mode==='aura'?speaking:hovered||focused)&&!motion.matches&&!button.disabled;
  if(active&&!instance)instance=vfx.createEffect(effect,{seed:42});
  if(!active&&instance){instance.stop();vfx.removeEffect(instance,true);instance=null;}
 }
 const handlers={pointerenter:()=>{hovered=true;sync()},pointerleave:()=>{hovered=false;sync()},focus:()=>{focused=true;sync()},blur:()=>{focused=false;sync()},click:()=>activationCount++};
 for(const [e,f] of Object.entries(handlers))button.addEventListener(e,f);motion.addEventListener('change',sync);
 portrait.hidden=dialogue.hidden=mode!=='aura';button.hidden=mode!=='ember';
 document.querySelector('#camera-control').hidden=document.querySelector('#scale-control').hidden=true;
 const action=document.querySelector('#action');action.textContent=mode==='aura'?'Pause speaking':'Disable button';
 action.onclick=()=>{if(mode==='aura'){speaking=!speaking;document.querySelector('#speaker').textContent=speaking?'Alin speaking':'Alin listening';action.textContent=speaking?'Pause speaking':'Resume speaking';}else{button.disabled=!button.disabled;if(button.disabled){hovered=false;focused=false;}action.textContent=button.disabled?'Enable button':'Disable button';}sync()};
 function tick(t){if(disposed||document.hidden)return;const target=mode==='aura'?portrait:button,b=target.getBoundingClientRect(),s=stage.getBoundingClientRect();
  if(mode==='aura'){mask.clear().rect(b.left-s.left,b.top-s.top,136,120).fill(0xffffff);}
  if(instance)instance.setPosition([(b.left-s.left+b.width/2)/pixelsPerUnit,(b.top-s.top+(mode==='aura'?64:b.height/2))/pixelsPerUnit,0]);
  vfx.update(Math.min(t.deltaMS/1000,0.05));
  window.recipeState={mode,hovered,focused,speaking,disabled:button.disabled,reducedMotion:motion.matches,activationCount,disposed,stats:{...vfx.stats}};
  document.querySelector('#stats').textContent=JSON.stringify(window.recipeState,null,2);
 }
 app.ticker.add(tick);sync();
 function dispose(){if(disposed)return;disposed=true;app.ticker.remove(tick);for(const[e,f]of Object.entries(handlers))button.removeEventListener(e,f);motion.removeEventListener('change',sync);vfx.destroy();app.destroy(true,{children:true});button.disabled=true;action.disabled=true;window.recipeState={mode,disposed:true};document.querySelector('#status').textContent='Disposed';document.querySelector('#dispose').disabled=true;}
 document.querySelector('#dispose').onclick=dispose;window.addEventListener('pagehide',dispose,{once:true});document.querySelector('#status').textContent='Ready';
}
