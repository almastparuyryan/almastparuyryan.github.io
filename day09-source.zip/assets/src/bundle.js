import {loadVfxExportBundle} from 'nixie-fx/export';
import manifest from '../vfx-project/out/vfx/manifest.json';
const exports=import.meta.glob('../vfx-project/out/vfx/effects/*.json',{eager:true,import:'default'});
export async function loadEffect(id,backend){
 const effectsByPath=Object.fromEntries(Object.entries(exports).map(([p,v])=>[p.split('/out/vfx/')[1],v]));
 const bundle=loadVfxExportBundle({manifest,effectsByPath},{requiredBackend:backend,requiredEffectIds:[id]});
 const effect=bundle.effectsById.get(id);const entry=manifest.effects.find(e=>e.id===id);
 if(entry.support.backends[backend].status!=='supported')throw new Error('Review backend support for '+id);
 return {effect,entry};
}
