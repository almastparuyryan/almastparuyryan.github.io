# Day 13 integration lab

Synthetic fixtures for keyboard focus/hover, crafting sparks, corridor motes and footstep pooling. Original integration source generated with AI for NixieFX marketing. No production game footage or performance guarantee.

## Reproduce

Use a Node version supported by Vite 8, then run:

```sh
npm install
node prepare-effects.mjs
node verify-runtime.mjs
npm run dev
```

Choose a mode in the navigation. `Fixed sample` holds a deterministic frame for visual inspection. `Dispose` removes owned resources. The reduced-motion checkbox is a test control, not automatic OS preference integration. For production, initialize and subscribe to `prefers-reduced-motion` and retain static focus/status feedback.

The Pixi adapter uses spawn/reset/stop/setPosition. The Three adapter uses restart/allowCompletion/setTransform. One animation loop advances the active renderer in seconds; Pixi's automatic ticker is stopped in this fixture.

`node prepare-effects.mjs` generates the authoring project and validates/exports it. To keep hand-edited effects, run the CLI directly against `vfx-project` instead of regenerating. The runtime consumes the exported bundle, not authoring JSON.

## Scope

- Hover: OR of pointer hover and native DOM focus. 24 particles/second; lifetime 0.35 seconds. The effect clears on loss of both states or reduced motion.
- Craft: one retained instance, 18-particle burst, 0.45-second lifetime. Repeated input resets/coalesces existing particles.
- Fog: 12 particles/second, four-second lifetime, cap 48, size 0.045 world units; transparent, depth test on, depth write off. No volumetric scattering, soft-depth sampling or target-device overdraw benchmark.
- Dust: four precreated instances, four contacts/second, eight particles/contact, lifetime 0.55 seconds. Node verification checks 40 contacts over ten simulated seconds, peak 24 active particles, no busy-slot reuse and complete drain.

World-space fixtures have Three GPU depth semantics; the export explicitly notes that Pixi uses 2D ordering instead. Material graphs, file textures and subemitters are not tested here.

Pinned versions are in package.json. Dependency licenses are included. The synthetic checks measure counts/lifecycle and material state, not GPU timing or zero-allocation behavior.
