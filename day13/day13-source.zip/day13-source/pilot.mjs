import { readFile } from 'node:fs/promises';
const rows = JSON.parse(await readFile(process.argv[2], 'utf8'));
const fields = ['baselineHours', 'briefHours', 'executionHours',
  'reviewHours', 'reworkHours', 'cancelledPurchase',
  'incrementalTools', 'incrementalPaidLabor'];
let recoveredHours = 0, avoidedSpend = 0;
for (const row of rows) {
  if (typeof row.accepted !== 'boolean') throw Error('acceptance missing');
  for (const key of fields) {
    if (!Number.isFinite(row[key]) || row[key] < 0) {
      throw Error(`${row.id}: invalid ${key}`);
    }
  }
  const attention = row.briefHours + row.executionHours +
    row.reviewHours + row.reworkHours;
  recoveredHours += (row.accepted ? row.baselineHours : 0) - attention;
  avoidedSpend += (row.accepted ? row.cancelledPurchase : 0) -
    row.incrementalTools - row.incrementalPaidLabor;
}
console.log(JSON.stringify({
  accepted: rows.filter(r => r.accepted).length,
  recoveredHours: +recoveredHours.toFixed(3),
  avoidedSpend: +avoidedSpend.toFixed(2)
}, null, 2));