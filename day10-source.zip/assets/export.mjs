import {spawnSync} from 'node:child_process';import {fileURLToPath} from 'node:url';import {mkdir,cp,readFile,writeFile} from 'node:fs/promises';import {loadVfxExportBundle} from 'nixie-fx/export';
const cli=fileURLToPath(new URL('./dist/cli.js',import.meta.resolve('nixie-fx/package.json')));
for(const action of ['validate','export']){const r=spawnSync(process.execPath,[cli,action,'./vfx-project'],{encoding:'utf8'});console.log(r.stdout,r.stderr);if(r.status)process.exit(r.status);}
await mkdir('public/vfx',{recursive:true});await cp('vfx-project/out/vfx','public/vfx',{recursive:true});
const manifest=JSON.parse(await readFile('public/vfx/manifest.json','utf8'));const effectsByPath=Object.fromEntries(await Promise.all(manifest.effects.map(async e=>[e.path,JSON.parse(await readFile('public/vfx/'+e.path,'utf8'))])));
const bundle=loadVfxExportBundle({manifest,effectsByPath},{requiredBackend:'three3d'});await writeFile('../evidence/export-check.json',JSON.stringify({ids:[...bundle.effectsById.keys()],effects:manifest.effects.map(e=>({id:e.id,support:e.support})),assets:manifest.assets},null,2));
