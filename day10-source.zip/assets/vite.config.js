import {defineConfig} from 'vite';export default defineConfig({base:'./',build:{assetsDir:'day10-assets',rolldownOptions:{input:['index.html','hf.html','fixtures.html']}}});
