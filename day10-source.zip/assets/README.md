# Day 10 runtime fixtures

Requires Node.js and npm. Install the pinned dependencies with `npm install`, then run `node export.mjs`, `node verify-runtime.mjs`, and `npm run dev`. Run `npm run build` for a static build. The authored JSON and synthetic atlas live in `vfx-project/`. The verified export is copied to `public/vfx/`.

Modes: embers, rain, laser, atlas, and seeds. The runtime uses Three.js. The host controls impact positions and orientations. Atlas frame variants derive from an exported definition after bundle verification. The module has partial export support; the tested constant-frame subset is documented in the numeric check. This source does not claim full collision, arbitrary packed-atlas handling, cross-backend pixel equality, GPU benchmarking or completed human review.

Seeds use one effect sampled at 0.35 seconds before instance translation. Wind reverses the initial X velocity with seed 42 and samples at one second. Laser orientation maps local +Z to the supplied normal. Rain impacts come from a host timer. Dispose scene releases owned resources. Browser screenshots are actual captures of these synthetic fixtures.
