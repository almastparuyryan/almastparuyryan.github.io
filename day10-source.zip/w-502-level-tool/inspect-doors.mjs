import {openSync,readSync,closeSync,fstatSync} from 'node:fs';
export function inspectDoors(level){
 if(!level||!Array.isArray(level.rooms)||!Array.isArray(level.doors))throw new Error('Expected rooms and doors arrays');
 if(level.rooms.length>100||level.doors.length>200)throw new Error('Training fixture limit exceeded');
 const rooms=new Set();for(const r of level.rooms){if(typeof r.id!=='string'||!r.id.trim()||rooms.has(r.id))throw new Error('Missing or duplicate room id');rooms.add(r.id)}
 const ids=new Set(),routes=new Set(),issues=[];
 for(const d of level.doors){if(typeof d.id!=='string'||!d.id.trim()||ids.has(d.id))throw new Error('Missing or duplicate door id');ids.add(d.id);if(!rooms.has(d.from)||!rooms.has(d.to))throw new Error('Door references unknown room: '+d.id);if(d.from===d.to)throw new Error('Self route: '+d.id);const route=JSON.stringify([d.from,d.to]);if(routes.has(route))issues.push({door:d.id,issue:'duplicate directed route',from:d.from,to:d.to});routes.add(route)}
 return {mode:'read-only',roomCount:rooms.size,doorCount:ids.size,issues};
}
if(import.meta.url===new URL(process.argv[1],'file:').href){try{
 if(!process.argv[2])throw new Error('Usage: node inspect-doors.mjs level.json');
 const fd=openSync(process.argv[2],'r'),data=Buffer.alloc(65537);let used=0;
 try{if(!fstatSync(fd).isFile())throw new Error('Expected a regular file');while(used<data.length){const count=readSync(fd,data,used,data.length-used,null);if(count===0)break;used+=count}}
 finally{closeSync(fd)}
 if(used>65536)throw new Error('Fixture exceeds 64 KiB');
 console.log(JSON.stringify(inspectDoors(JSON.parse(data.subarray(0,used).toString('utf8'))),null,2));
}catch(e){console.error('ERROR: '+e.message);process.exitCode=1}}
