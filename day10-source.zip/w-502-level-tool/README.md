# Read-only duplicate-door inspection fixture

Run `node inspect-doors.mjs level.json` with Node.js. The synthetic three-room file has three doors and one repeated directed route. The inspector reports `gate-c` as a duplicate route from `lobby` to `garden`. It reads one explicitly supplied JSON file, prints a report, and does not save a corrected level.

This is a training artifact, not a production level format. A duplicate route can be intentional in a real game. The level designer judges intent and a qualified engineer reviews schema assumptions, input limits and integration before production use. A successful execution does not establish completed human review.

Review checklist: confirm the actual level schema, inspect all file and process access, decide whether direction matters, supply malformed and oversized fixtures, verify no source changes, and attach the engineer's review identity and decision. A designer should reproduce the reported route on the level map and reject any proposed change that removes intentional alternate doors.
