import json, pathlib, copy
from PIL import Image, ImageDraw
p=pathlib.Path(__file__).resolve().parent
a=p/'assets'; (a/'src').mkdir(parents=True,exist_ok=True)
(a/'vfx-project/effects').mkdir(parents=True,exist_ok=True)
(a/'vfx-project/assets').mkdir(parents=True,exist_ok=True)
starter=json.load(open(p.parent/'day-09/assets/starter-effect.json'))
project=json.load(open(p.parent/'day-09/assets/starter-project.json'))
project.update(id='day10-examples',name='Wind, surface impacts, atlas frames and repeatable seeds')
project['settings']['lastEffectFile']='campfire-embers.json'
(a/'vfx-project/vfx-editor.prj').write_text(json.dumps(project,indent=2))
def constant(v): return dict(mode='constant',value=v,min=v,max=v,curve=[dict(x=0,y=v),dict(x=1,y=v)],curveB=[dict(x=0,y=v),dict(x=1,y=v)])
specs=[
 ('campfire-embers',24,2,56,.055,[1,.45,.08,.95],[-.16,.7,-.16],[.16,1.1,.16],0,[.35,.05,.35]),
 ('rain-impact',0,.45,16,.065,[.3,.75,1,.9],[-.7,.18,-.7],[.7,.55,.7],12,[0,0,0]),
 ('wall-sparks',0,.6,28,.05,[1,.5,.1,1],[-.9,-.9,.7],[.9,.9,1.3],24,[0,0,0]),
 ('seed-burst',0,.8,32,.075,[.3,.9,.65,1],[-1,-1,0],[1,1,0],24,[.15,.15,0]),
 ('atlas-frames',0,2,4,.7,[1,1,1,1],[0,0,0],[0,0,0],1,[0,0,0]),
]
for id,rate,life,cap,size,color,vmin,vmax,burst,box in specs:
 f=copy.deepcopy(starter); f.update(id=id,name=id,targetProfile='portable' if id in ('seed-burst','atlas-frames') else 'three-world-3d')
 f['timeline']['duration']=3 if rate else life+.2
 e=f['emitters'][0];e.update(id=id+'-emitter',name=id,maxParticles=cap,loop=bool(rate),duration=1 if rate else .05)
 e['spawn'].update(shape='box',box=box,radius=0,radiusValue=constant(0),rate=rate,rateValue=constant(rate),simulationSpace='local',bursts=[dict(time=0,count=burst,cycles=1,interval=0,probability=1)] if burst else [])
 e['initializeParticle']['lifetime']=constant(life);e['initializeParticle']['size']=constant(size)
 e['initializeParticle']['velocity'].update(mode='vector',min=vmin,max=vmax,speed=constant(0))
 e['initializeParticle']['color'].update(color=color,colorB=color)
 e['billboard'].update(sizeStart=size,sizeEnd=size,sizeValue=constant(size))
 e['color'].update(start=color,end=color[:3]+[0])
 e['color']['gradient']['colorStops']=[dict(position=0,color=color[:3]),dict(position=1,color=color[:3])]
 e['color']['gradient']['alphaStops']=[dict(position=0,alpha=color[3]),dict(position=.7,alpha=color[3]),dict(position=1,alpha=0)]
 e['render'].update(depthTest=True,depthWrite=False,depthInk=False,blend='alpha')
 if id=='atlas-frames':
  e['modules']['textureSheetAnimation']=True
  e['render']['texture']='atlas-4.png'
  e['advanced']['textureSheetAnimation'].update(tiles=[2,2],startFrame=0,endFrame=3,cycles=1,randomStartFrame=False,frameOverTime=constant(0))
 (a/f'vfx-project/effects/{id}.json').write_text(json.dumps(f,indent=2))
im=Image.new('RGBA',(256,256));d=ImageDraw.Draw(im)
for i,c in enumerate(['#ff7447','#5bc9ec','#dca6ff','#86dfaf']):
 x=(i%2)*128;y=(i//2)*128
 d.rectangle((x+4,y+4,x+123,y+123),fill=c)
 if i==0:d.ellipse((x+36,y+36,x+92,y+92),fill='#16222f')
 elif i==1:d.polygon([(x+64,y+24),(x+104,y+96),(x+24,y+96)],fill='#16222f')
 elif i==2:d.rectangle((x+32,y+32,x+96,y+96),fill='#16222f')
 else:d.line((x+28,y+28,x+100,y+100),fill='#16222f',width=16);d.line((x+28,y+100,x+100,y+28),fill='#16222f',width=16)
im.save(a/'vfx-project/assets/atlas-4.png')
(a/'package.json').write_text(json.dumps(dict(name='day10-runtime-examples',private=True,type='module',scripts={'dev':'vite --host 127.0.0.1 --port 5190','build':'vite build'},dependencies={'nixie-fx':'0.1.17','three':'0.185.1','pixi.js':'8.19.0'},devDependencies={'vite':'8.3.1'}),indent=2))
(a/'vite.config.js').write_text("import {defineConfig} from 'vite';export default defineConfig({base:'./',build:{assetsDir:'day10-assets'}});\n")
