# Read only level inspection fixture

This fictional training-room fixture supports W-503 and W-510. Requires Node.js; no packages, network, credentials, game install, or write operation.

```sh
node inspect-level.mjs level.json
```

Compare stdout with `expected-output.json`. The coordinate convention is zero-based X/Y: 0 ≤ X < width and 0 ≤ Y < height. A malformed fixture, duplicate ID, or out-of-bounds spawn returns exit code 1 and an error on stderr. The script prints a summary; it does not modify or import a level. Qualified human review remains pending.
