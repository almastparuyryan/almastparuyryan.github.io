import {readFileSync} from 'node:fs';
try{
 const path=process.argv[2];if(!path)throw new Error('Usage: node inspect-level.mjs level.json');
 const raw=readFileSync(path,'utf8');if(raw.length>65536)throw new Error('Fixture exceeds 64 KiB');const level=JSON.parse(raw);
 if(!level||typeof level.name!=='string'||!level.name.trim())throw new Error('Missing level name');
 const {width,height}=level.bounds||{};if(!Number.isFinite(width)||width<=0||!Number.isFinite(height)||height<=0)throw new Error('Bounds must be positive finite numbers');
 if(!Array.isArray(level.spawns)||!level.spawns.length)throw new Error('Missing spawns');const ids=new Set();
 for(const s of level.spawns){if(!s||typeof s.id!=='string'||!s.id.trim()||ids.has(s.id))throw new Error('Missing or duplicate spawn ID');ids.add(s.id);if(!Number.isFinite(s.x)||!Number.isFinite(s.y)||s.x<0||s.x>=width||s.y<0||s.y>=height)throw new Error('Spawn outside bounds: '+s.id);}
 const summary={level:level.name,spawnCount:level.spawns.length,spawnIds:level.spawns.map(s=>s.id),bounds:{width,height},mode:'read-only'};
 console.log(JSON.stringify(summary,null,2));
}catch(e){console.error('ERROR: '+e.message);process.exitCode=1;}
