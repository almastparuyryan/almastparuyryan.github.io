# Run the Day 7 particle recipes

This application supplies the original runnable assets for N-358, N-241, N-303, N-466, and N-427. It contains two PixiJS fixtures and three Three.js fixtures. All consume compiled NixieFX exports through the public loader.

## Local preview

```sh
cd "day-07/assets"
npm install
npm run dev
```

Choose Item reveal, Healing bar, Fireflies, Footstep dust, or Waterfall mist. This workspace reuses the previously installed Day 1 dependencies through a local symlink; on another machine, remove that symlink and run `npm install`. Dependencies are pinned in package.json. Node 22.13.1 was used for the build.

## Change and rebuild effects

The source lives in `vfx-project/effects`; runtime output lives in `vfx-project/out/vfx`. Never edit the output to change appearance.

```sh
npx nixie-fx validate vfx-project
npx nixie-fx export vfx-project
npx nixie-fx export-status vfx-project
```

Copy the resulting `out/vfx` directory to `public/vfx`, then run `npm run build`. `configure-effects.mjs` reproduces the recipe settings on the generated source. It changes emitter IDs, so do not run it as part of every ordinary rebuild.

## Controls and checks

- Replay/Restart triggers a recipe; footstep dust instead toggles walking.
- Pause gates updates. Resume resets the frame-clock reference.
- Dispose releases VFX resources and removes the owning callback.
- Save measurement JSON prepares a local observation download. The browser automation download-event handoff timed out; verify file saving manually before depending on it.
- The on-screen counters expose capacity, live particles, effect count, and missing/unsupported diagnostics. They are observations, not mobile benchmarks.

For Pixi fixtures, `maxBoundsDelta` tracks the card's dimensions and content position. It does not measure every screen pixel or a general responsive layout. For Three fixtures, update duration measures a JavaScript call, while host draw calls include the simple ground and prop. The dust pool is explicitly host-owned and contains four instances.

Review the source project in the real editor before final artistic sign-off. Keep backend support notes: Pixi depth behavior differs from Three's depth buffer. No custom material, particle file texture, collision, trail, or terrain contact is demonstrated here.
