import { readFile, writeFile } from 'node:fs/promises';
import { randomUUID } from 'node:crypto';
const specs = [
 ['rarity-reveal',18,0.65,18,3.5,[0.75,0.45,1,1],18,0],
 ['healing-glow',20,0.55,14,2,[0.3,1,0.65,1],14,0],
 ['ambient-fireflies',48,4,0.075,0.06,[1,0.85,0.3,0.7],0,10],
 ['footstep-dust',24,0.6,0.09,0.35,[0.65,0.55,0.42,0.45],8,0],
 ['waterfall-mist',72,1.5,0.3,0.18,[0.6,0.85,1,0.28],0,36]
];
function scalar(s,v){s.mode='constant';s.value=s.min=s.max=v;for(const k of ['curve','curveB'])s[k]?.forEach(p=>p.y=v);}
for(const [id,cap,life,size,speed,color,burst,rate] of specs){
 const path=`vfx-project/effects/${id}.json`;
 const fx=JSON.parse(await readFile(path,'utf8'));const e=fx.emitters[0];
 e.id=`emitter-${randomUUID()}`;e.loop=!burst;e.duration=burst?0.1:1;e.maxParticles=cap;
 fx.timeline.duration=burst?life+0.1:5;
 e.spawn.rate=rate;scalar(e.spawn.rateValue,rate);
 e.spawn.bursts=burst?[{time:0,count:burst,cycles:1,interval:0,probability:1}]:[];
 e.spawn.shape=id==='ambient-fireflies'||id==='waterfall-mist'?'box':'circle';
 e.spawn.box=id==='ambient-fireflies'?[4,2,2]:[1.2,0.1,0.5];
 e.spawn.radius=burst?(id==='footstep-dust'?0.08:70):0;scalar(e.spawn.radiusValue,e.spawn.radius);
 e.modules.velocity=true;e.modules.color=true;
 scalar(e.initializeParticle.velocity.speed,speed);scalar(e.initializeParticle.lifetime,life);
 e.initializeParticle.color.color=e.initializeParticle.color.colorB=color;
 e.color.start=color;e.color.end=[...color.slice(0,3),0];
 e.color.gradient.colorStops=[{position:0,color:color.slice(0,3)},{position:1,color:color.slice(0,3)}];
 e.color.gradient.alphaStops=[{position:0,alpha:0},{position:0.15,alpha:1},{position:1,alpha:0}];
 e.billboard.sizeStart=e.billboard.sizeEnd=size;scalar(e.billboard.sizeValue,size);scalar(e.initializeParticle.size,size);
 e.render.depthWrite=false;e.render.depthInk=false;
 if(id==='rarity-reveal'||id==='healing-glow'){e.render.depthTest=false;e.render.sortMode='none';}
 if(id==='healing-glow'){e.spawn.shape='box';e.spawn.box=[250,16,0];}
 if(id==='ambient-fireflies'){e.modules.noise=false;}
 await writeFile(path,JSON.stringify(fx,null,2)+'\n');
}
