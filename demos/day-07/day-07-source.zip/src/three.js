import * as THREE from 'three';
import {ThreeVfxRenderer} from 'nixie-fx/three';
import {loadBundle} from './bundle.js';
export async function runThree(mode){
 const id={fireflies:'ambient-fireflies',dust:'footstep-dust',mist:'waterfall-mist'}[mode];
 const {effect,entry}=await loadBundle('three3d',id);
 const host=document.querySelector('#stage');const scene=new THREE.Scene();scene.background=new THREE.Color(0x141e2b);
 const camera=new THREE.PerspectiveCamera(50,900/420,0.1,50);camera.position.set(4,3,6);camera.lookAt(0,0.7,0);
 const renderer=new THREE.WebGLRenderer({antialias:true});renderer.setSize(900,420);host.append(renderer.domElement);
 const ground=new THREE.Mesh(new THREE.PlaneGeometry(9,7),new THREE.MeshBasicMaterial({color:0x233b36}));ground.rotation.x=-Math.PI/2;scene.add(ground);
 const prop=new THREE.Mesh(new THREE.BoxGeometry(mode==='mist'?1.4:0.35,mode==='mist'?2.5:0.7,0.5),new THREE.MeshBasicMaterial({color:mode==='mist'?0x4a728d:0x41615c}));prop.position.set(0,mode==='mist'?1.25:0.35,0);scene.add(prop);
 const vfx=new ThreeVfxRenderer({scene,camera,captureDebugTransforms:false});
 const pool=mode==='dust'?Array.from({length:4},()=>vfx.createEffect(effect,{seed:42,autoStart:false})):[];
 let ambient=mode==='dust'?null:vfx.createEffect(effect,{position:[0,mode==='mist'?0.15:1.3,0],seed:42});
 const metrics={id,versions:{nixieFx:'0.1.17',three:'0.185.1'},poolSize:pool.length,createdInstances:pool.length+(ambient?1:0),requestedFootfalls:0,acceptedFootfalls:0,droppedFootfalls:0,records:[]};
 let paused=false,disposed=false,moving=true,last=performance.now(),seconds=0,nextFootfall=0,frameId;
 const buttons=['trigger','pause','dispose','download'].map(id=>document.querySelector('#'+id));buttons.forEach(b=>b.disabled=false);
 buttons[0].textContent=mode==='dust'?'Stop walking':'Restart';
 buttons[0].onclick=()=>{if(mode==='dust'){moving=!moving;buttons[0].textContent=moving?'Stop walking':'Start walking';}else ambient.restart();};
 buttons[1].onclick=()=>{paused=!paused;buttons[1].textContent=paused?'Resume':'Pause';last=performance.now();};
 const dispose=()=>{if(disposed)return;disposed=true;cancelAnimationFrame(frameId);vfx.destroy();scene.traverse(o=>{o.geometry?.dispose();if(o.material)o.material.dispose();});renderer.dispose();buttons.slice(0,3).forEach(b=>b.disabled=true);document.querySelector('#status').textContent='Disposed: RAF canceled and host/VFX resources released.';};buttons[2].onclick=dispose;
 buttons[3].onclick=()=>{const u=URL.createObjectURL(new Blob([JSON.stringify(metrics,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=u;a.download=`${id}-measurement.json`;a.click();setTimeout(()=>URL.revokeObjectURL(u),500);};
 function frame(now){if(disposed)return;frameId=requestAnimationFrame(frame);const dt=Math.min((now-last)/1000,0.05);last=now;if(paused||document.hidden)return;seconds+=dt;
  if(mode==='dust'&&moving){prop.position.x=Math.sin(seconds*0.5)*2;
   if(seconds>=nextFootfall){nextFootfall=seconds+0.25;metrics.requestedFootfalls++;const fx=pool.find(f=>!f.isActive);if(fx){fx.setTransform({position:[prop.position.x,0.08,0]});fx.restart();metrics.acceptedFootfalls++;}else metrics.droppedFootfalls++;}}
  const begin=performance.now();vfx.update(dt);const updateMs=performance.now()-begin;renderer.render(scene,camera);
  const row={seconds:+seconds.toFixed(2),updateMs,...vfx.stats,hostDrawCalls:renderer.info.render.calls};
  if(!metrics.records.length||seconds-metrics.records.at(-1).seconds>=0.1){metrics.records.push(row);if(metrics.records.length>1200)metrics.records.shift();}
  document.querySelector('#stats').textContent=JSON.stringify({seconds:+seconds.toFixed(1),createdInstances:metrics.createdInstances,requestedFootfalls:metrics.requestedFootfalls,acceptedFootfalls:metrics.acceptedFootfalls,droppedFootfalls:metrics.droppedFootfalls,...vfx.stats,hostDrawCalls:renderer.info.render.calls},null,2);
 }frameId=requestAnimationFrame(frame);
 window.addEventListener('pagehide',dispose,{once:true});
 document.querySelector('#status').textContent=`Ready: ${id}; Three support ${entry.support.backends.three3d.status}. Seed 42. No file textures or custom materials.`;
}
