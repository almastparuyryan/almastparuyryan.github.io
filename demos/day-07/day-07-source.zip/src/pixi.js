import {Application,Container,Graphics,Assets,Sprite,Text} from 'pixi.js';
import {PixiVfxRenderer,createPixiVfx2dProjection} from 'nixie-fx/pixi';
import {loadBundle} from './bundle.js';
export async function runPixi(mode){
 const id=mode==='rarity'?'rarity-reveal':'healing-glow';
 const {effect,entry}=await loadBundle('pixi2d',id);
 const stage=document.querySelector('#stage');const app=new Application();
 await app.init({width:900,height:420,background:0x141e2b,antialias:true});stage.append(app.canvas);
 const content=new Container();content.position.set(450,210);app.stage.addChild(content);
 const bg=new Graphics().roundRect(-150,-110,300,220,20).fill(0x243146);content.addChild(bg);
 const item=await Assets.load(new URL('./item.svg',document.baseURI).href);
 let icon;
 if(mode==='rarity'){icon=new Sprite(item);icon.anchor.set(0.5);icon.position.set(0,-25);content.addChild(icon);}
 const bar=new Graphics().roundRect(-125,-14,250,28,8).fill(0x172334);
 const fill=new Graphics().roundRect(0,0,250,28,8).fill(0x59d697);fill.position.set(-125,-14);fill.scale.x=0.4;
 if(mode==='heal'){content.addChild(bar,fill);}
 const label=new Text({text:mode==='rarity'?'Epic · Crystal shard':'40 / 100 HP',style:{fill:0xf0eefc,fontSize:22,fontFamily:'system-ui'}});label.anchor.set(0.5);label.position.set(0,70);content.addChild(label);
 // VFX is a sibling of the layout container. Its bounds never determine UI size.
 const layer=new Container();app.stage.addChild(layer);const vfx=new PixiVfxRenderer({parent:layer,projection:createPixiVfx2dProjection({originX:0,originY:0,pixelsPerUnit:1,yAxis:'down'})});
 const live=new Set();let disposed=false,paused=false,triggerCount=0,maxBoundsDelta=0;
 const baseline={x:content.x,y:content.y,width:bg.width,height:bg.height};
 const records=[];
 function trigger(){if(disposed)return;for(const old of live)vfx.removeEffect(old,true);live.clear();
  if(mode==='heal'){fill.scale.x=fill.scale.x>0.8?0.4:Math.min(1,fill.scale.x+0.2);label.text=`${Math.round(fill.scale.x*100)} / 100 HP`;}
  const point=content.toGlobal({x:0,y:mode==='rarity'?-25:0});
  live.add(vfx.createEffect(effect,{position:[point.x,point.y,0],seed:42}));triggerCount++;
 }
 const controls=['trigger','pause','dispose','download'].map(id=>document.querySelector('#'+id));controls.forEach(b=>b.disabled=false);
 controls[0].onclick=trigger;
 controls[1].onclick=()=>{paused=!paused;controls[1].textContent=paused?'Resume':'Pause';};
 function dispose(){if(disposed)return;disposed=true;app.ticker.remove(tick);vfx.destroy();live.clear();layer.destroy();controls.slice(0,3).forEach(b=>b.disabled=true);document.querySelector('#status').textContent='Disposed: ticker callback removed and VFX renderer destroyed.';}
 controls[2].onclick=dispose;
 controls[3].onclick=()=>{const data={id,versions:{nixieFx:'0.1.17',pixi:'8.19.0'},triggerCount,maxBoundsDelta,baseline,records};download(data,`${id}-measurement.json`);};
 let elapsed=0;
 function tick(t){if(paused||document.hidden)return;vfx.update(Math.min(t.deltaMS/1000,0.05));
  for(const fx of live)if(!fx.isActive){vfx.removeEffect(fx,true);live.delete(fx);}
  const current={x:content.x,y:content.y,width:bg.width,height:bg.height};
  const delta=Math.max(...Object.keys(baseline).map(k=>Math.abs(current[k]-baseline[k])));maxBoundsDelta=Math.max(delta,maxBoundsDelta);
  elapsed+=t.deltaMS/1000;
  const row={seconds:+elapsed.toFixed(2),activeEffects:live.size,boundsDelta:delta,...vfx.stats};
  if(!records.length||elapsed-records.at(-1).seconds>=0.1){records.push(row);if(records.length>1200)records.shift();}
  document.querySelector('#stats').textContent=JSON.stringify({triggerCount,maxBoundsDelta,...vfx.stats},null,2);
 }
 app.ticker.add(tick);window.addEventListener('pagehide',()=>{dispose();app.destroy(true,{children:true});void Assets.unload(new URL('./item.svg',document.baseURI).href);},{once:true});
 document.querySelector('#status').textContent=`Ready: ${id}; Pixi support ${entry.support.backends.pixi2d.status}. Item texture loaded before replay.`;
}
export function download(data,name){const u=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=u;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(u),500);}
