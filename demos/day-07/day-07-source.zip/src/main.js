import './style.css';
import {runPixi} from './pixi.js';
import {runThree} from './three.js';
const mode=new URLSearchParams(location.search).get('mode')||'fireflies';
const labels={rarity:['Item rarity reveal without layout shift','Preloaded item texture, fixed card bounds, and a separate effect layer.'],heal:['A healing glow that follows the health bar','Health changes are authoritative. The glow supplies short-lived visual feedback.'],fireflies:['Ambient fireflies with a bounded population','A small world-space volume, slow movement, and depth-tested particles.'],dust:['Footstep dust with an explicit instance pool','A synthetic walking marker emits timed footfalls while a bounded pool reuses completed effects.'],mist:['Waterfall mist beside a level prop','A shallow emitter at the basin with capacity and live particle counters.']};
const [title,intro]=labels[mode]||labels.fireflies;
document.querySelector('#title').textContent=title;document.querySelector('#intro').textContent=intro;
Promise.resolve(mode==='rarity'||mode==='heal'?runPixi(mode):runThree(labels[mode]?mode:'fireflies')).catch(e=>{document.querySelector('#status').textContent=e.message;console.error(e);});
