import './style.css';
import {runThree} from './three.js';
runThree('fireflies').catch(e=>{document.querySelector('#status').textContent=e.message;console.error(e);});
