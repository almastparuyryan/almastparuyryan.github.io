import {loadVfxExportBundle,parseVfxExportManifest} from 'nixie-fx/export';
export async function loadBundle(backend,id){
 // index.html is at the deployment root, so resolve public assets there.
 const base=new URL('./vfx/',document.baseURI);
 async function json(path){const r=await fetch(new URL(path,base));if(!r.ok)throw new Error(`Asset request failed: ${path} (${r.status})`);return r.json();}
 const raw=await json('manifest.json');const manifest=parseVfxExportManifest(raw);
 const entry=manifest.effects.find(e=>e.id===id);if(!entry)throw new Error(`Missing ${id}`);
 const support=entry.support.backends[backend];
 if(support.status!=='supported')throw new Error(`Review required: ${id} is ${support.status} on ${backend}`);
 const effectsByPath=Object.fromEntries(await Promise.all(manifest.effects.map(async e=>[e.path,await json(e.path)])));
 const bundle=loadVfxExportBundle({manifest:raw,effectsByPath},{requiredBackend:backend,requiredEffectIds:[id]});
 const effect=bundle.effectsById.get(id);if(!effect)throw new Error(`Missing effect ${id}`);
 return {bundle,effect,entry,base,manifest,support};
}
