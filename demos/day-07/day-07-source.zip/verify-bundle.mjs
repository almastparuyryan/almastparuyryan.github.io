import {readFile,writeFile} from 'node:fs/promises';
import {loadVfxExportBundle} from 'nixie-fx/export';
const base='public/vfx/';
const manifest=JSON.parse(await readFile(base+'manifest.json','utf8'));
const effectsByPath=Object.fromEntries(await Promise.all(manifest.effects.map(async e=>[e.path,JSON.parse(await readFile(base+e.path,'utf8'))])));
const results=[];
for(const backend of ['pixi2d','three3d']){
 const bundle=loadVfxExportBundle({manifest,effectsByPath,assetPaths:[]},{requiredBackend:backend,requireEveryAsset:true,requiredEffectIds:manifest.effects.map(e=>e.id)});
 results.push({backend,loadedEffectIds:[...bundle.effectsById.keys()]});
}
const report={verifiedAt:new Date().toISOString(),packageVersion:'0.1.17',generatedAt:manifest.generatedAt,sourceHash:manifest.sourceHash,validation:manifest.validation,results,support:manifest.effects.map(e=>({id:e.id,support:e.support}))};
await writeFile('../evidence/bundle-verification.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({validationValid:manifest.validation.valid,blockers:manifest.validation.blockers.length,results},null,2));
