# Day 12 synthetic particle receipts

Pinned nixie-fx 0.1.17, Three.js 0.185.1 and PixiJS 8.19.0. Only Three.js is rendered by this demo.

From assets/: npm install; node prepare-effects.mjs; node verify-runtime.mjs; npm run dev. Open ?mode=wall, beam, density or stress. npm run build produces static output.

Wall uses a fixed sample at 0.2 seconds, authored +Z rotated to supplied +X. Beam uses world simulation space and host movement. Density uses host-selected multipliers, not automatic runtime adaptation. Stress logs CPU update time separately from requestAnimationFrame intervals, excludes 30 warm-up frames, keeps 240 samples and provides cleanup. These are synthetic fixtures, not target-device performance or game collision checks.

fixtures/valid and fixtures/invalid-missing-effect hold complete loader input maps. evidence/runtime-checks.json contains actual Node results; evidence/stress-browser.json holds the live browser receipt. Counts differ between fixed CPU steps and live rendering boundaries. Capture-debug transforms are disabled in browser stress mode.
