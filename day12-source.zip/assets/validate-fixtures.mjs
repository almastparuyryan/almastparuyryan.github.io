import { readFile } from 'node:fs/promises';
import { loadVfxExportBundle } from 'nixie-fx/export';

const read = async path => JSON.parse(await readFile(path, 'utf8'));
for (const folder of ['valid', 'invalid-missing-effect']) {
  try {
    const manifest = await read(`../fixtures/${folder}/manifest.json`);
    const effectsByPath = await read(`../fixtures/${folder}/effectsByPath.json`);
    const bundle = loadVfxExportBundle(
      { manifest, effectsByPath },
      { requiredBackend: 'three3d' }
    );
    console.log(folder, 'accepted', bundle.effectsById.size);
  } catch (error) {
    console.log(folder, 'rejected', error.message);
  }
}
