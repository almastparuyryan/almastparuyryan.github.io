import {readFile,writeFile,mkdir,cp} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {loadVfxExportBundle} from 'nixie-fx/export';
const constant=value=>({mode:'constant',value,min:value,max:value,curve:[{x:0,y:value},{x:1,y:value}],curveB:[{x:0,y:value},{x:1,y:value}]});
const project=JSON.parse(await readFile('starter-project.json','utf8'));project.id='day12-recipes';project.name='Impact, heal pulse and teleport receipt';project.settings.lastEffectFile='wall-impact.json';
await mkdir('vfx-project/effects',{recursive:true});await writeFile('vfx-project/vfx-editor.prj',JSON.stringify(project,null,2));
for(const s of [
 {id:'wall-impact',profile:'three-world-3d',count:32,life:.6,size:.065,color:[1,.6,.18,1],shape:'box',box:[.04,.04,0],rotation:[0,0,0],radius:0,vmin:[-1,-1,1],vmax:[1,1,3]},
 {id:'beam-endpoint',profile:'three-world-3d',count:128,life:.4,size:.065,color:[.2,.8,1,1],shape:'box',box:[.04,.04,0],rotation:[0,0,0],radius:0,vmin:[-.3,-.3,-.3],vmax:[.3,.3,.3],rate:60},
 {id:'portable-density',profile:'portable',count:128,life:1,size:.065,color:[1,.6,.18,1],shape:'box',box:[.04,.04,0],rotation:[0,0,0],radius:0,vmin:[-.6,-.6,0],vmax:[.6,.6,0],rate:120}
]){
 const fx=JSON.parse(await readFile('starter-effect.json','utf8'));Object.assign(fx,{id:s.id,name:s.id,targetProfile:s.profile});fx.timeline.duration=1.2;
 const e=fx.emitters[0];Object.assign(e,{id:s.id+'-emitter',name:s.id,maxParticles:s.count,duration:s.rate?2:.05,loop:!!s.rate});
 Object.assign(e.spawn,{shape:s.shape,box:s.box,rotation:s.rotation,radius:s.radius,radiusValue:constant(s.radius),radiusThickness:0,simulationSpace:s.id==='beam-endpoint'?'world':'local',rate:s.rate||0,rateValue:constant(s.rate||0),bursts:s.rate?[]:[{time:0,count:s.count,cycles:1,interval:0,probability:1}]});
 e.initializeParticle.lifetime=constant(s.life);e.initializeParticle.size=constant(s.id==='wall-impact'?1:s.size);Object.assign(e.initializeParticle.velocity,{mode:'vector',min:s.vmin,max:s.vmax,speed:constant(0)});e.initializeParticle.color.color=s.color;e.initializeParticle.color.colorB=s.color;
 Object.assign(e.billboard,{sizeStart:s.size,sizeEnd:s.size,sizeValue:constant(s.size)});e.color.start=s.color;e.color.end=[...s.color.slice(0,3),0];e.color.gradient.colorStops=[{position:0,color:s.color.slice(0,3)},{position:1,color:s.color.slice(0,3)}];e.color.gradient.alphaStops=[{position:0,alpha:0},{position:.1,alpha:1},{position:1,alpha:0}];
 Object.assign(e.render,{depthTest:s.profile!=='portable',depthWrite:false,depthInk:false,blend:'alpha'});
 await writeFile(`vfx-project/effects/${s.id}.json`,JSON.stringify(fx,null,2));
}
const cli=fileURLToPath(new URL('./dist/cli.js',import.meta.resolve('nixie-fx/package.json')));
for(const action of ['validate','export']){const r=spawnSync(process.execPath,[cli,action,'./vfx-project'],{encoding:'utf8'});console.log(r.stdout,r.stderr);if(r.status)process.exit(r.status);}
await mkdir('public/vfx',{recursive:true});await cp('vfx-project/out/vfx','public/vfx',{recursive:true});
const manifest=JSON.parse(await readFile('public/vfx/manifest.json','utf8'));
const effectsByPath=Object.fromEntries(await Promise.all(manifest.effects.map(async e=>[e.path,JSON.parse(await readFile('public/vfx/'+e.path,'utf8'))])));
await writeFile('../evidence/export-check.json',JSON.stringify({support:manifest.effects.map(e=>({id:e.id,support:e.support}))},null,2));
