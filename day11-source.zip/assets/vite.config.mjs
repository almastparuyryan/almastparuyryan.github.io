export default {base:'./',build:{rollupOptions:{output:{inlineDynamicImports:true}}}};
