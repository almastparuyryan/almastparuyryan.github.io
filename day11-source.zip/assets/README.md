# Day 11 reproducible particle fixtures

Synthetic examples for pinned nixie-fx 0.1.17, PixiJS 8.19.0 and Three.js 0.185.1.

From this assets directory, run `npm install`, `node prepare-effects.mjs`, `node verify-runtime.mjs`, then `npm run dev`. Open the displayed localhost URL with `?mode=impact`, `?mode=heal` or `?mode=ring`. `npm run build` creates the static build.

The portable impact and heal use the same compiled definitions in both rendering backends. PixiJS uses an upward Y axis at 80 pixels/unit; the host applies the sign when converting the canvas center. Three.js uses a perspective camera. The separate teleport ring is an XZ world effect. Sample time, camera and uniform scale are explicit controls. Fixed samples use Three.js seek and small PixiJS update steps. Dispose releases the runtime and host resources.

Export support reports, numeric checks, actual browser captures and rendered counts are separate evidence. None establishes production performance, target-device coverage, exact pixel equality, collision behavior or completed human art acceptance. The partial PixiJS depth note belongs to the separate world effect, not the two portable definitions.

The parent `fixtures/verify-handoffs.mjs` script resolves paths relative to its own extracted source root. Run `node fixtures/verify-handoffs.mjs` from that root. It generates disposable SVGs and checks dimensions, file identity, six ASCII search inputs and placeholder preservation. It is not a general SVG security validator or linguistic approval.
