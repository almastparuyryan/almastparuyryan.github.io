import {readFile,writeFile,mkdir} from 'node:fs/promises';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import {ThreeVfxRenderer} from 'nixie-fx/three';
import {loadVfxExportBundle} from 'nixie-fx/export';
const manifest=JSON.parse(await readFile('public/vfx/manifest.json'));
const effectsByPath=Object.fromEntries(await Promise.all(manifest.effects.map(async e=>[e.path,JSON.parse(await readFile('public/vfx/'+e.path))])));
const bundle=loadVfxExportBundle({manifest,effectsByPath},{requiredBackend:'three3d'}),scene=new THREE.Scene(),camera=new THREE.PerspectiveCamera(),vfx=new ThreeVfxRenderer({scene,camera,captureDebugTransforms:true});
const result={scope:'Export validation and Three.js CPU runtime, fixed 1/60-second steps. No GPU benchmark.',versions:{nixieFx:'0.1.17',three:'0.185.1'},seed:157,samples:[],manifest:[]};
const step=n=>{for(let i=0;i<n;i++)vfx.update(1/60);};
const points=f=>f.getParticleDebugTransforms().map(t=>t.position);
for(const id of ['waterfall','projectile','spawn','lifecycle']){const f=vfx.createEffect(bundle.effectsById.get(id),{seed:157});step(id==='waterfall'?180:18);const count=f.stats.activeParticles;assert(count>0);assert(count<=f.stats.capacity);assert.equal(f.stats.unsupportedFeatures.length,0);result.samples.push({id,timeSeconds:id==='waterfall'?3:.3,active:count,capacity:f.stats.capacity});
if(id==='waterfall')assert(Math.abs(count-54)<=1);
if(id==='spawn'){assert.equal(count,48);step(48);assert.equal(f.stats.activeParticles,0);result.spawnExpiredBy1point1Seconds=true;}
if(id==='lifecycle'){const before=JSON.stringify(points(f));f.pause();step(60);assert.equal(JSON.stringify(points(f)),before);f.play();step(12);assert.notEqual(JSON.stringify(points(f)),before);f.stop();f.restart();step(18);const restarted=JSON.stringify(points(f));assert.equal(restarted,before);result.lifecycle={pausePreservedPositions:true,resumeChangedPositions:true,restartReplayedSeed:true};}
f.allowCompletion();step(180);assert.equal(f.stats.activeParticles,0);vfx.removeEffect(f,true);}
result.manifest.push({fixture:'valid',accepted:bundle.effectsById.size});
const missing=structuredClone(effectsByPath);delete missing['effects/lifecycle.json'];
try{loadVfxExportBundle({manifest,effectsByPath:missing},{requiredBackend:'three3d'});assert.fail('Expected loader rejection');}catch(error){assert(!error.message.includes('Expected loader rejection'));result.manifest.push({fixture:'invalid-missing-effect',rejected:true,error:error.message});}
loadVfxExportBundle({manifest,effectsByPath},{requiredBackend:'pixi2d',requiredEffectIds:['lifecycle']});result.portableLifecycleValidated=true;
await mkdir('fixtures/valid',{recursive:true});await mkdir('fixtures/invalid',{recursive:true});await writeFile('fixtures/valid/input.json',JSON.stringify({manifest,effectsByPath},null,2));await writeFile('fixtures/invalid/input.json',JSON.stringify({manifest,effectsByPath:missing},null,2));
vfx.destroy();assert.equal(scene.children.length,0);result.destroyRemovedRoots=true;
await mkdir('evidence',{recursive:true});await writeFile('evidence/runtime-checks.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
