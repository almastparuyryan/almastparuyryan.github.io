import {readFile,writeFile,mkdir,cp} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
const c=v=>({mode:'constant',value:v,min:v,max:v,curve:[{x:0,y:v},{x:1,y:v}],curveB:[{x:0,y:v},{x:1,y:v}]});
await mkdir('vfx-project/effects',{recursive:true});
const project=JSON.parse(await readFile('starter-project.json'));Object.assign(project,{id:'day15-effects',name:'Mist, projectile, spawn and lifecycle'});project.settings.lastEffectFile='lifecycle.json';await writeFile('vfx-project/vfx-editor.prj',JSON.stringify(project,null,2));
for(const s of [
{id:'waterfall',max:72,life:1.8,size:.25,rate:30,box:[1.3,.1,.35],vmin:[-.12,.12,-.08],vmax:[.12,.3,.08],color:[.72,.86,1,.24]},
{id:'projectile',max:64,life:.45,size:.10,rate:100,box:[.04,.04,.04],vmin:[-.06,-.06,-.06],vmax:[.06,.06,.06],color:[.3,.55,1,.85],world:true},
{id:'spawn',max:48,life:.7,size:.12,count:48,box:[.7,1.5,.7],vmin:[-.12,.15,-.12],vmax:[.12,.4,.12],color:[.45,.95,.85,.8]},
{id:'lifecycle',max:40,life:1,size:.11,rate:24,box:[1.5,.3,0],vmin:[0,.4,0],vmax:[0,.6,0],color:[1,.65,.25,.9],portable:true}
]){const fx=JSON.parse(await readFile('starter-effect.json'));Object.assign(fx,{id:s.id,name:s.id,targetProfile:s.portable?'portable':'three-world-3d'});fx.timeline.duration=s.rate?12:1.2;const e=fx.emitters[0];Object.assign(e,{id:s.id+'-emitter',name:s.id,maxParticles:s.max,duration:s.rate?12:.05,loop:!!s.rate});
Object.assign(e.spawn,{shape:'box',box:s.box,simulationSpace:s.world?'world':'local',rate:s.rate||0,rateValue:c(s.rate||0),bursts:s.rate?[]:[{time:0,count:s.count,cycles:1,interval:0,probability:1}]});
e.initializeParticle.lifetime=c(s.life);e.initializeParticle.size=c(s.size);Object.assign(e.initializeParticle.velocity,{mode:'vector',min:s.vmin,max:s.vmax,speed:c(0)});e.initializeParticle.color.color=s.color;e.initializeParticle.color.colorB=s.color;Object.assign(e.billboard,{sizeStart:s.size,sizeEnd:s.size,sizeValue:c(s.size)});e.color.start=s.color;e.color.end=[...s.color.slice(0,3),0];e.color.gradient.colorStops=[{position:0,color:s.color.slice(0,3)},{position:1,color:s.color.slice(0,3)}];e.color.gradient.alphaStops=[{position:0,alpha:0},{position:.15,alpha:s.color[3]},{position:1,alpha:0}];Object.assign(e.render,{depthTest:!s.portable,depthWrite:false,depthInk:false,blend:s.id==='projectile'?'additive':'alpha'});
await writeFile('vfx-project/effects/'+s.id+'.json',JSON.stringify(fx,null,2));}
for(const action of ['validate','export']){const r=spawnSync(process.execPath,['node_modules/nixie-fx/dist/cli.js',action,'./vfx-project'],{encoding:'utf8'});console.log(r.stdout,r.stderr);if(r.status)process.exit(r.status);}
await cp('vfx-project/out/vfx','public/vfx',{recursive:true});
