import {readFile} from 'node:fs/promises';
import {loadVfxExportBundle} from 'nixie-fx/export';
try {const input=JSON.parse(await readFile(process.argv[2]||'fixtures/valid/input.json','utf8'));const b=loadVfxExportBundle(input,{requiredBackend:'three3d',requiredEffectIds:['lifecycle']});console.log(`ACCEPT: ${b.effectsById.size} effects`);}catch(error){console.error(`REJECT: ${error.message}`);process.exitCode=1;}
